# Optimizador — núcleo (Kotlin / Android)

Base del proyecto: mide el celular, calcula un puntaje de salud (0-100)
y genera recomendaciones. Está pensado para sumarle después:

1. **Comunidad:** enviar `CommunityReport` (anónimo, opt-in) y recibir
   recomendaciones probadas en celulares del mismo modelo.
2. **Adaptación automática:** aprender qué apps abre la persona y a qué
   hora, y reaccionar cuando el celular empieza a trabarse.
3. **Launcher / UI:** pantallas de Inicio, Diagnóstico y Perfiles.

## Permisos
- `PACKAGE_USAGE_STATS` (la persona lo concede en Ajustes) para ver apps activas.

## Pendiente antes de compilar
- Crear el proyecto en Android Studio (Empty Activity, Jetpack Compose) y copiar `core/`.
- Declarar el permiso en `AndroidManifest.xml`.
- Este código no se compiló todavía: hay que probarlo en un celular real.
