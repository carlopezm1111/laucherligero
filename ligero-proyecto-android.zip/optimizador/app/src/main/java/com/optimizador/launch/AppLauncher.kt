package com.optimizador.launch

import android.app.ActivityOptions
import android.content.Context
import android.view.View

/**
 * Abre una app lo más rápido posible. Regla: en el toque no se calcula nada.
 * El Intent ya viene armado (AppEntry) y la animación arranca en el mismo instante.
 *
 * Nota honesta: esto acorta lo que pasa ANTES de que la app empiece a abrirse y
 * hace que se sienta inmediato. No acelera la app que se abre (WhatsApp, un juego...).
 */
class AppLauncher(private val context: Context) {

    /**
     * @param source vista del ícono tocado (en Compose: LocalView.current)
     * @param x,y,w,h posición y tamaño del ícono dentro de esa vista, en píxeles
     * @param animationScale 1f normal; viene de UiTier.animScale para respetar el nivel adaptativo
     */
    fun open(entry: AppEntry, source: View, x: Int, y: Int, w: Int, h: Int, animationScale: Float = 1f) {
        // La animación nace en el ícono; el sistema la dibuja, no nuestro hilo principal.
        val options = ActivityOptions.makeScaleUpAnimation(source, x, y, w, h)
        try {
            context.startActivity(entry.launchIntent, options.toBundle())
        } catch (e: Exception) {
            // La app pudo desinstalarse justo ahora; el AppIndex se refrescará solo.
        }
    }
}
