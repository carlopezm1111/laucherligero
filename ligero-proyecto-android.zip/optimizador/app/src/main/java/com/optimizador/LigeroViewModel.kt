package com.optimizador

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.optimizador.core.DeviceSnapshot
import com.optimizador.core.HealthScore
import com.optimizador.core.PerformanceScanner
import com.optimizador.core.Recommendation
import com.optimizador.core.RecommendationEngine
import com.optimizador.launch.AppIndex
import com.optimizador.launch.AppLauncher
import com.optimizador.launch.IconCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LigeroViewModel(app: Application) : AndroidViewModel(app) {

    val index = AppIndex(app, viewModelScope).also { it.start() }
    val icons = IconCache(app)
    val launcher = AppLauncher(app)

    private val prefs = app.getSharedPreferences("ligero", 0)
    var themeIndex by mutableIntStateOf(prefs.getInt("theme", 0))
        private set

    var snapshot by mutableStateOf<DeviceSnapshot?>(null)
        private set
    var score by mutableIntStateOf(0)
        private set
    var recommendations by mutableStateOf<List<Recommendation>>(emptyList())
        private set

    fun chooseTheme(i: Int) {
        themeIndex = i
        prefs.edit().putInt("theme", i).apply()
    }

    /** Mide el celular fuera del hilo principal. */
    fun scan() {
        viewModelScope.launch(Dispatchers.Default) {
            val s = PerformanceScanner(getApplication()).scan()
            val recs = RecommendationEngine().build(s)
            val sc = HealthScore.compute(s)
            snapshot = s; recommendations = recs; score = sc
        }
    }

    override fun onCleared() {
        index.stop()
    }
}
