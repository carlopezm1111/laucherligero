package com.optimizador.launch

import android.content.Context
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.os.Process
import android.util.LruCache
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Dibuja cada ícono una sola vez, a tamaño pequeño, y lo guarda en memoria.
 * Usa el ícono ORIGINAL de cada app (el mismo que ves en el launcher de fábrica).
 * El tope de memoria es una fracción pequeña de la disponible, para no pesar en celulares viejos.
 */
class IconCache(context: Context) {

    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val me = Process.myUserHandle()

    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 24).toInt().coerceIn(2_000_000, 12_000_000)
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    suspend fun load(entry: AppEntry): Bitmap? = withContext(Dispatchers.IO) {
        val key = entry.component.flattenToString()
        cache.get(key)?.let { return@withContext it }
        val info = launcherApps.resolveActivity(entry.launchIntent, me) ?: return@withContext null
        val bmp = info.getBadgedIcon(0).toBitmap(ICON_PX, ICON_PX)
        cache.put(key, bmp)
        bmp
    }

    private companion object { const val ICON_PX = 128 }
}
