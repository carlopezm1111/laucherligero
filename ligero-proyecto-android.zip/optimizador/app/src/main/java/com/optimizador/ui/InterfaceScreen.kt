package com.optimizador.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.AdaptiveUiController
import com.optimizador.adaptive.UiTier

private val DESCRIPCIONES = mapOf(
    UiTier.COMPLETO to "Vidrio y animaciones completas. Para celulares potentes.",
    UiTier.EQUILIBRADO to "Menos efectos. Para celulares de gama media.",
    UiTier.LIGERO to "Paneles sólidos, sin transparencias. Para celulares viejos."
)

@Composable
fun InterfaceScreen(vm: LigeroViewModel, controller: AdaptiveUiController, tier: UiTier, theme: LigeroTheme) {
    val ctx = LocalContext.current
    val sample by controller.lastSample.collectAsState()
    var auto by remember { mutableStateOf(controller.auto) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        LText("Interfaz adaptativa", 27, FontWeight.Bold)
        LText("Se ajusta sola para que nunca se trabe.", 15, alpha = .8f)

        LiquidPanel(tier, theme, Modifier.fillMaxWidth()) {
            Row(Modifier.padding(20.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    LText("Fluidez en vivo", 13, alpha = .8f)
                    LText("${sample?.fps ?: "–"} fps", 30, FontWeight.Bold, color = theme.highlight)
                }
                Column(horizontalAlignment = Alignment.End) {
                    LText("Tirones", 13, alpha = .8f)
                    LText("${((sample?.jankRatio ?: 0f) * 100).toInt()}%", 22, FontWeight.SemiBold)
                }
            }
        }

        UiTier.entries.forEach { t ->
            val selected = t == tier
            LiquidPanel(
                tier, theme,
                Modifier.fillMaxWidth().clickable { controller.setManual(t); auto = false }
                    .border(if (selected) 2.dp else 0.dp, if (selected) theme.highlight else Color.Transparent, RoundedCornerShape(24.dp))
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    LText(t.name.lowercase().replaceFirstChar { it.uppercase() } + if (selected) " · activo" else "", 17, FontWeight.Bold)
                    LText(DESCRIPCIONES.getValue(t), 13, alpha = .8f)
                }
            }
        }

        LiquidPanel(tier, theme, Modifier.fillMaxWidth()) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    LText("Ajuste automático", 15, FontWeight.SemiBold)
                    LText("Cambia de nivel según la fluidez", 13, alpha = .8f)
                }
                Switch(checked = auto, onCheckedChange = { auto = it; controller.auto = it })
            }
        }

        LText("Color de la interfaz", 15, alpha = .8f)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LigeroThemes.forEachIndexed { i, th ->
                val sel = i == vm.themeIndex
                androidx.compose.foundation.layout.Box(
                    Modifier.size(44.dp)
                        .background(Brush.linearGradient(listOf(th.blobs[0], th.blobs[1])), CircleShape)
                        .border(3.dp, if (sel) Color.White else Color.Transparent, CircleShape)
                        .clickable { vm.chooseTheme(i) }
                )
            }
        }

        GlassButton("Usar Ligero como pantalla de inicio", tier, theme) {
            ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        androidx.compose.foundation.layout.Spacer(Modifier.size(90.dp))
    }
}
