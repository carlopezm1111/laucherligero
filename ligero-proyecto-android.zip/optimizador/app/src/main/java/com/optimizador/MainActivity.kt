package com.optimizador

import android.app.ActivityManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.optimizador.adaptive.AdaptiveUiController
import com.optimizador.ui.LigeroApp

class MainActivity : ComponentActivity() {

    private val vm: LigeroViewModel by viewModels()
    private lateinit var controller: AdaptiveUiController

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val mem = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mem)
        val totalRamMb = mem.totalMem / (1024 * 1024)
        val refreshRate = windowManager.defaultDisplay.refreshRate

        controller = AdaptiveUiController(totalRamMb, refreshRate)
        setContent { LigeroApp(vm, controller) }
    }

    override fun onStart() { super.onStart(); controller.start() }
    override fun onStop() { controller.stop(); super.onStop() }
}
