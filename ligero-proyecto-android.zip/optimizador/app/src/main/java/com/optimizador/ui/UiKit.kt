package com.optimizador.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.optimizador.adaptive.UiTier

data class LigeroTheme(
    val name: String,
    val base: Color,
    val blobs: List<Color>,
    val panel: Color,
    val highlight: Color
)

private fun c(v: Long) = Color(v)

val LigeroThemes = listOf(
    LigeroTheme("Aurora", c(0xFF0B1030), listOf(c(0xFF4B6BFF), c(0xFFB14DFF), c(0xFF00C2B8), c(0xFFFF6FA8)), c(0xFF1B2250), c(0xFF9DF2D2)),
    LigeroTheme("Atardecer", c(0xFF2A0F1F), listOf(c(0xFFFF7A45), c(0xFFFF3D77), c(0xFFFFB020), c(0xFF8A2BE2)), c(0xFF3A1A2C), c(0xFFFFD9A0)),
    LigeroTheme("Océano", c(0xFF04182E), listOf(c(0xFF1E90FF), c(0xFF00B8D9), c(0xFF2DD4BF), c(0xFF3B5BFF)), c(0xFF0C2A47), c(0xFFA5F3FC)),
    LigeroTheme("Bosque", c(0xFF07210F), listOf(c(0xFF22A94F), c(0xFF7BC62D), c(0xFF0E9F8A), c(0xFFC8D93A)), c(0xFF123A1E), c(0xFFC8F7A0)),
    LigeroTheme("Violeta", c(0xFF150A33), listOf(c(0xFF7C3AED), c(0xFFD946EF), c(0xFF6366F1), c(0xFFF472B6)), c(0xFF261452), c(0xFFE9D5FF)),
    LigeroTheme("Grafito", c(0xFF0F1115), listOf(c(0xFF3B4252), c(0xFF5B6578), c(0xFF2B3340), c(0xFF707C92)), c(0xFF20242C), c(0xFFE5E9F0))
)

/** Fondo: COMPLETO usa 4 manchas de color, EQUILIBRADO 2, LIGERO color sólido (más barato de dibujar). */
@Composable
fun Wallpaper(theme: LigeroTheme, tier: UiTier, content: @Composable BoxScope.() -> Unit) {
    val centers = listOf(Offset(.15f, .1f), Offset(.9f, .3f), Offset(.25f, .85f), Offset(.85f, .95f))
    Box(
        Modifier.fillMaxSize().drawBehind {
            drawRect(theme.base)
            val spots = when (tier) { UiTier.COMPLETO -> 4; UiTier.EQUILIBRADO -> 2; UiTier.LIGERO -> 0 }
            for (i in 0 until spots) {
                drawRect(
                    Brush.radialGradient(
                        listOf(theme.blobs[i].copy(alpha = .85f), Color.Transparent),
                        center = Offset(size.width * centers[i].x, size.height * centers[i].y),
                        radius = size.width * 0.85f
                    )
                )
            }
        },
        content = content
    )
}

/** Panel "de vidrio": translúcido con borde brillante; en nivel LIGERO, sólido y sin transparencias. */
@Composable
fun LiquidPanel(
    tier: UiTier,
    theme: LigeroTheme,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val fill = if (tier.glass)
        Modifier.background(Brush.linearGradient(listOf(Color.White.copy(.22f), Color.White.copy(.07f))), shape)
    else
        Modifier.background(theme.panel, shape)
    Box(
        modifier.then(fill).border(1.dp, Color.White.copy(if (tier.glass) .3f else .18f), shape).clip(shape),
        content = content
    )
}

@Composable
fun LText(
    text: String,
    size: Int = 15,
    weight: FontWeight = FontWeight.Normal,
    alpha: Float = 1f,
    color: Color = Color.White,
    modifier: Modifier = Modifier,
    align: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE
) = Text(
    text, modifier, color.copy(alpha = alpha), size.sp, fontWeight = weight,
    textAlign = align, maxLines = maxLines, overflow = TextOverflow.Ellipsis
)
