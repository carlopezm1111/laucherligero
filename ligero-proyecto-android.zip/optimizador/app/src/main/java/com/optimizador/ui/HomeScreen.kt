package com.optimizador.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier
import com.optimizador.launch.AppEntry
import com.optimizador.launch.instantTap
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    val apps by vm.index.apps.collectAsState()
    var query by remember { mutableStateOf("") }
    val shown = remember(query, apps) { vm.index.search(query) }
    val now by produceState(LocalDateTime.now()) {
        while (true) { value = LocalDateTime.now(); delay(20_000) }
    }
    val locale = Locale.forLanguageTag("es")

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(12.dp))
        LText(now.format(DateTimeFormatter.ofPattern("HH:mm")), 60, FontWeight.Light)
        LText(now.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", locale)), 15, alpha = .85f)
        Spacer(Modifier.height(16.dp))

        LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(50)) {
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 15.dp),
                decorationBox = { inner ->
                    if (query.isEmpty()) LText("Buscar apps al instante", 16, alpha = .7f)
                    inner()
                }
            )
        }
        Spacer(Modifier.height(10.dp))

        vm.snapshot?.let {
            LiquidPanel(tier, theme, Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        LText("Salud del celular", 13, alpha = .8f)
                        LText("${vm.score} / 100", 26, FontWeight.Bold, color = theme.highlight)
                    }
                    LText("Nivel\n${tier.name.lowercase().replaceFirstChar { c -> c.uppercase() }}", 13, align = TextAlign.End)
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(bottom = 110.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(shown, key = { it.component.flattenToString() }) { entry ->
                AppCell(entry, vm, tier)
            }
        }
    }
}

@Composable
private fun AppCell(entry: AppEntry, vm: LigeroViewModel, tier: UiTier) {
    val view = LocalView.current
    val bounds = remember { IntArray(4) }
    val icon by produceState<ImageBitmap?>(null, entry.component) {
        value = vm.icons.load(entry)?.asImageBitmap()
    }
    Column(
        Modifier
            .padding(vertical = 8.dp)
            .onGloballyPositioned {
                val p = it.positionInRoot()
                bounds[0] = p.x.toInt(); bounds[1] = p.y.toInt()
                bounds[2] = it.size.width; bounds[3] = it.size.height
            }
            .instantTap {
                vm.launcher.open(entry, view, bounds[0], bounds[1], bounds[2], bounds[3], tier.animScale)
            },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(56.dp)) {
            icon?.let { Image(it, contentDescription = null, modifier = Modifier.fillMaxSize()) }
        }
        LText(entry.label, 11, maxLines = 1, align = TextAlign.Center)
    }
}
