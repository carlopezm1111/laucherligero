package com.optimizador.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.AdaptiveUiController

private val TABS = listOf("Inicio", "Diagnóstico", "Interfaz")

@Composable
fun LigeroApp(vm: LigeroViewModel, controller: AdaptiveUiController) {
    val tier by controller.tier.collectAsState()
    val theme = LigeroThemes[vm.themeIndex.coerceIn(LigeroThemes.indices)]
    var tab by remember { mutableIntStateOf(0) }

    MaterialTheme {
        Wallpaper(theme, tier) {
            Box(Modifier.fillMaxSize()) {
                Crossfade(tab, animationSpec = tween((250 * tier.animScale).toInt()), label = "tab") { t ->
                    when (t) {
                        0 -> HomeScreen(vm, tier, theme)
                        1 -> DiagnosticScreen(vm, tier, theme)
                        else -> InterfaceScreen(vm, controller, tier, theme)
                    }
                }
                LiquidPanel(
                    tier, theme,
                    Modifier.align(Alignment.BottomCenter).navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth(),
                    RoundedCornerShape(30.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        TABS.forEachIndexed { i, name ->
                            Box(
                                Modifier.weight(1f).heightIn(min = 48.dp).clickable { tab = i },
                                contentAlignment = Alignment.Center
                            ) {
                                LText(
                                    name, 14,
                                    if (i == tab) FontWeight.Bold else FontWeight.Normal,
                                    color = if (i == tab) theme.highlight else androidx.compose.ui.graphics.Color.White,
                                    align = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
