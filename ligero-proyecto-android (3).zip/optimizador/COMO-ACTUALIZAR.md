# Cómo subir esta actualización (paso a paso)

## A. Una sola vez: guardar la llave de firma (4 secretos)
1. Abre el archivo SECRETOS-GITHUB.txt (no está dentro del zip, se entrega aparte).
2. En GitHub, en tu repositorio: Settings > Secrets and variables > Actions > New repository secret.
3. Crea los 4 secretos con el nombre y valor exactos: KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD y KEYSTORE_B64.

## B. Una sola vez: cambiar el archivo de compilación
1. En el repositorio abre `.github/workflows/main.yml`, toca el lápiz (editar).
2. Borra todo y pega el contenido del archivo main.yml que se entrega aparte. Confirma con Commit changes.

## C. Subir el proyecto nuevo
1. Add file > Upload files > elige `ligero-proyecto-android.zip` (mismo nombre, reemplaza el anterior). Commit changes.
2. En Actions, espera el círculo verde (unos 3 a 5 minutos). Si sale una X roja, copia el error del paso "Compilar" y envíalo.
3. En Releases aparece la versión nueva (v0.2.N) con el archivo `ligero.apk`.

## D. Instalar (la primera vez hay que desinstalar la versión anterior)
La versión que tienes instalada está firmada con una llave de pruebas distinta. Android no deja instalar
encima, así que esta vez: desinstala Ligero, instala `ligero.apk` y vuelve a elegirlo como pantalla de inicio.
Desde esta versión en adelante, las actualizaciones se instalan encima sin perder nada (Ajustes > Buscar actualizaciones).

## Enlace fijo para la página de descarga
https://github.com/carlopezm1111/laucherligero/releases/latest/download/ligero.apk
