# Servidor de Nova (opcional)

Sin este servidor, Nova funciona igual con sus comandos propios (gratis e ilimitados).
Con él, además responde preguntas libres con una IA gratuita y, si la persona lo permite,
ayuda a otros celulares iguales con resultados anónimos.

**Ningún servicio gratuito de IA es ilimitado.** Este servidor reparte las consultas entre varios
y pone un límite por celular (30 al día) y uno global (5.000 al día) para que el cupo alcance.
Cuando se acaba, Nova lo dice con honestidad. Los límites y las condiciones de cada proveedor cambian:
revísalos antes de publicar la app.

## Cómo instalarlo (Cloudflare, plan gratuito)
1. Crea una cuenta en dash.cloudflare.com.
2. Workers y Pages > Create > Worker. Ponle de nombre `nova-ligero`, toca Deploy y luego Edit code.
   Borra todo, pega el contenido de `worker.js` y toca Deploy.
3. Storage y bases de datos > KV > Create. Crea dos espacios: `RL` y `TIPS`.
4. En tu Worker: Settings > Bindings > Add:
   - KV namespace, variable `RL`, espacio `RL`.
   - KV namespace, variable `TIPS`, espacio `TIPS`.
   - Workers AI, variable `AI` (es la IA gratuita de Cloudflare; no necesita clave).
5. (Opcional) Settings > Variables y secretos:
   - `GROQ_API_KEY` y/o `GEMINI_API_KEY`: segundo y tercer proveedor gratuito. OJO: el plan gratuito de
     Gemini puede usar las conversaciones para mejorar sus productos; si no quieres eso, no lo configures.
   - `DAILY_LIMIT` (por celular, por defecto 30) y `GLOBAL_LIMIT` (por defecto 5000).
6. Copia la dirección de tu Worker (algo como `https://nova-ligero.TU-USUARIO.workers.dev`) y pégala en
   Ligero: Ajustes > Nova y comunidad > Servidor de Nova.
7. Prueba abriendo esa dirección en el navegador: debe mostrar `{"ok":true,...}`.

## Qué se envía y qué se guarda
- Al chatear: el texto que escribe la persona, los nombres de sus apps (para poder abrirlas) y un
  identificador aleatorio del celular que solo sirve para contar las consultas del día.
- Resultados de la comunidad: solo si la persona activa «Compartir resultados anónimos»: modelo del celular,
  puntajes antes y después, y qué acciones se aplicaron. Se guardan solo contadores, y los consejos solo se
  muestran cuando hay al menos 3 reportes del mismo modelo.
- No se guardan nombres, ubicación ni listas de apps.

Este código no se ha probado en un servidor real.
