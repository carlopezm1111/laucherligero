// Servidor intermedio de Nova y de la comunidad de Ligero.
// Se despliega gratis en Cloudflare Workers. NO está probado todavía: revísalo antes de usarlo.
//
// Qué hace:
//  POST /chat    -> Nova pregunta algo; reparte entre IA gratuitas y limita las consultas diarias por celular.
//  POST /report  -> (opcional) resultado anónimo de "Revive tu celular": solo modelo, puntajes y acciones.
//  GET  /tips    -> qué les funcionó a otros celulares del mismo modelo (solo si hay al menos 3 reportes).
//
// Qué NO guarda: nombres, ubicación, listas de apps ni nada que identifique a una persona.

const SYSTEM = `Eres Nova, la asistente de un launcher de Android llamado Ligero. Respondes en español, corto y amable.
Puedes pedir UNA acción de esta lista, y solo esas:
- open_app: abrir una app. arg = nombre exacto de una de las apps de la lista "Apps".
- alarm: poner una alarma. arg = "HH:MM" en 24 horas.
- timer: temporizador. arg = segundos como número.
- web_search: buscar en internet. arg = texto a buscar.
- boost: acelerar el celular (sin arg).
- theme: cambiar el color. arg = aurora, atardecer, oceano, bosque, violeta, grafito o cristal.
- none: solo conversar.
Responde SIEMPRE y SOLO con JSON: {"reply":"...","action":"none","arg":"","arg2":""}.
Nunca inventes apps que no estén en la lista. Si no puedes hacer algo en el celular, dilo con honestidad.`;

const TIPS = {
  boost: "Cerrar procesos en segundo plano",
  cache: "Limpiar la caché",
};

const json = (o, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json; charset=utf-8" } });

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    try {
      if (request.method === "POST" && url.pathname === "/chat") return await chat(request, env);
      if (request.method === "POST" && url.pathname === "/report") return await report(request, env);
      if (request.method === "GET" && url.pathname === "/tips") return await tips(url, env);
      return json({ ok: true, name: "Servidor de Nova" });
    } catch (e) {
      return json({ error: "fallo" }, 500);
    }
  },
};

async function chat(request, env) {
  const body = await request.json();
  const text = String(body.text || "").slice(0, 400);
  const device = String(body.device || "").slice(0, 64);
  const apps = (Array.isArray(body.apps) ? body.apps : []).slice(0, 120).map((a) => String(a).slice(0, 40));
  if (!text || !device) return json({ error: "datos" }, 400);

  // Límites diarios: uno por celular y uno global, para que el cupo gratuito alcance para todos.
  const day = new Date().toISOString().slice(0, 10);
  const perDevice = parseInt(env.DAILY_LIMIT || "30", 10);
  const global = parseInt(env.GLOBAL_LIMIT || "5000", 10);
  const kDev = `rl:${device}:${day}`;
  const kGlob = `rl:global:${day}`;
  const usedDev = parseInt((await env.RL.get(kDev)) || "0", 10);
  const usedGlob = parseInt((await env.RL.get(kGlob)) || "0", 10);
  if (usedDev >= perDevice || usedGlob >= global) return json({ error: "limite" }, 429);
  await env.RL.put(kDev, String(usedDev + 1), { expirationTtl: 90000 });
  await env.RL.put(kGlob, String(usedGlob + 1), { expirationTtl: 90000 });

  const messages = [
    { role: "system", content: SYSTEM },
    { role: "user", content: `Apps: ${apps.join(", ")}\nPedido: ${text}` },
  ];

  // Cadena de proveedores gratuitos: el primero que responda gana.
  let raw = null;
  for (const provider of [cloudflareAI, groq, gemini]) {
    try {
      raw = await provider(env, messages);
      if (raw) break;
    } catch (e) {
      /* se prueba con el siguiente */
    }
  }
  if (!raw) {
    return json({ reply: "Ahora mismo no pude pensar la respuesta. Inténtalo en un rato.", action: "none", arg: "", arg2: "" });
  }
  return json(parseReply(raw));
}

async function cloudflareAI(env, messages) {
  if (!env.AI) return null;
  const r = await env.AI.run("@cf/meta/llama-3.1-8b-instruct", { messages, max_tokens: 300 });
  return r && r.response ? r.response : null;
}

async function groq(env, messages) {
  if (!env.GROQ_API_KEY) return null;
  const r = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${env.GROQ_API_KEY}` },
    body: JSON.stringify({ model: "llama-3.3-70b-versatile", messages, max_tokens: 300, temperature: 0.3 }),
  });
  if (!r.ok) return null;
  const j = await r.json();
  return j.choices && j.choices[0] && j.choices[0].message ? j.choices[0].message.content : null;
}

// Ojo: el plan gratuito de Gemini puede usar las conversaciones para mejorar sus productos.
// Si no quieres eso, no configures GEMINI_API_KEY y este paso se omite.
async function gemini(env, messages) {
  if (!env.GEMINI_API_KEY) return null;
  const r = await fetch("https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${env.GEMINI_API_KEY}` },
    body: JSON.stringify({ model: "gemini-2.5-flash", messages, max_tokens: 300, temperature: 0.3 }),
  });
  if (!r.ok) return null;
  const j = await r.json();
  return j.choices && j.choices[0] && j.choices[0].message ? j.choices[0].message.content : null;
}

function parseReply(raw) {
  const allowed = ["none", "open_app", "alarm", "timer", "web_search", "boost", "theme"];
  const m = String(raw).match(/\{[\s\S]*\}/);
  try {
    const o = JSON.parse(m[0]);
    return {
      reply: String(o.reply || "").slice(0, 500),
      action: allowed.includes(o.action) ? o.action : "none",
      arg: String(o.arg || "").slice(0, 120),
      arg2: String(o.arg2 || "").slice(0, 120),
    };
  } catch (e) {
    return { reply: String(raw).slice(0, 500), action: "none", arg: "", arg2: "" };
  }
}

async function report(request, env) {
  const b = await request.json();
  const model = String(b.model || "").slice(0, 40).toLowerCase();
  if (!model) return json({ error: "datos" }, 400);
  const ids = (Array.isArray(b.actions) ? b.actions : []).filter((a) => a in TIPS);
  const gain = Math.max(-20, Math.min(40, (b.after | 0) - (b.before | 0)));
  for (const id of ids) {
    const k = `tip:${model}:${id}`;
    const cur = JSON.parse((await env.TIPS.get(k)) || '{"n":0,"gain":0}');
    cur.n += 1;
    cur.gain += gain;
    await env.TIPS.put(k, JSON.stringify(cur));
  }
  return json({ ok: true });
}

async function tips(url, env) {
  const model = (url.searchParams.get("model") || "").slice(0, 40).toLowerCase();
  const out = [];
  for (const id of Object.keys(TIPS)) {
    const v = JSON.parse((await env.TIPS.get(`tip:${model}:${id}`)) || "null");
    if (v && v.n >= 3) out.push({ id, n: v.n, avg: Math.round(v.gain / v.n) });
  }
  out.sort((a, b) => b.avg - a.avg);
  return json({
    tips: out.slice(0, 3).map((t) => `${TIPS[t.id]}: en ${t.n} celulares iguales el puntaje cambió ${t.avg >= 0 ? "+" : ""}${t.avg} en promedio`),
  });
}
