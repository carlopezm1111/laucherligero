# Interfaz adaptativa

Mide los fotogramas del propio launcher (Choreographer) cada segundo y
cambia de nivel: COMPLETO -> EQUILIBRADO -> LIGERO.

- Baja tras 2 s seguidos con más de 15% de tirones.
- Sube solo tras 30 s fluidos, y nunca por encima del nivel que le toca por RAM.
- Si un nivel falla, no vuelve a probarlo en 10 min (evita parpadeos entre niveles).

## Cómo aplicar el nivel en la interfaz (Compose)
- COMPLETO / EQUILIBRADO: Modifier.blur(tier.blurDp.dp) en el fondo del panel + borde y brillo.
- LIGERO: color sólido, sin blur ni transparencias.
- Escala de animaciones: multiplicar las duraciones por tier.animScale.

## Pendiente
- No se compiló ni se probó. Hay que medir en celulares reales.
- Ajustar umbrales (15%, 3%, 2 s, 30 s) con datos; son valores iniciales.
- Escribir pruebas unitarias para TierDecider (es Kotlin puro, fácil de probar).
- Evitar medir mientras la pantalla está apagada o el launcher no es visible.
