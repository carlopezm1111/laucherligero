package com.optimizador.data

import androidx.compose.runtime.mutableStateListOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Registro de lo que hizo el motor de rendimiento. Se guarda para verlo aunque se cierre la app. */
class EngineLog(private val prefs: Prefs) {
    val events = mutableStateListOf<String>()

    init {
        prefs.getString("log")?.split("\n")?.filter { it.isNotBlank() }?.let { events.addAll(it) }
    }

    fun add(message: String) {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        events.add(0, "$time  $message")
        while (events.size > 30) events.removeAt(events.lastIndex)
        prefs.putString("log", events.joinToString("\n"))
    }
}
