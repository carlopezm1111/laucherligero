package com.optimizador.weather

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private class Drop(val x: Float, val y0: Float, val len: Float, val speed: Float)
private class Flake(val x: Float, val y0: Float, val r: Float, val speed: Float, val p: Float)
private class Star(val x: Float, val y: Float, val r: Float, val p: Float)
private class Cloud(val x: Float, val y: Float, val rFrac: Float, val v: Float)

/** Posiciones iniciales fijas (los números se calculan una vez por clima). */
private class Seeds(sky: Sky) {
    private val r = java.util.Random(7)
    val drops = List(
        when (sky) { Sky.TORMENTA -> 160; Sky.LLUVIA -> 100; else -> 0 }
    ) { Drop(r.nextFloat(), r.nextFloat(), 0.06f + r.nextFloat() * 0.08f, 3f + r.nextFloat() * 3f) }
    val flakes = List(if (sky == Sky.NIEVE) 80 else 0) {
        Flake(r.nextFloat(), r.nextFloat(), 1.4f + r.nextFloat() * 2.6f, 0.3f + r.nextFloat() * 0.5f, r.nextFloat() * 6f)
    }
    val stars = List(60) { Star(r.nextFloat(), r.nextFloat() * 0.75f, 0.6f + r.nextFloat() * 1.3f, r.nextFloat() * 6f) }
    val clouds = List(if (sky == Sky.SOL) 2 else 5) {
        Cloud(r.nextFloat(), 0.06f + r.nextFloat() * 0.42f, 0.17f + r.nextFloat() * 0.13f, 0.02f + r.nextFloat() * 0.04f)
    }
}

/**
 * Cielo animado: cambia con la hora (amanecer, mañana, tarde, atardecer, noche) y con el clima
 * (sol, nublado, lluvia, tormenta con relámpagos, nieve). Con animate = false dibuja un solo cuadro.
 */
@Composable
fun WeatherScene(sky: Sky, hour: Float, animate: Boolean, modifier: Modifier = Modifier) {
    val seeds = remember(sky) { Seeds(sky) }
    var tick by remember { mutableLongStateOf(3_000_000_000L) }
    LaunchedEffect(animate) {
        if (animate) {
            while (true) withFrameNanos { tick = it }
        } else {
            tick = 3_000_000_000L
        }
    }
    Canvas(modifier) { drawScene(seeds, sky, hour, tick / 1_000_000_000f) }
}

private fun DrawScope.cloudBlob(cx: Float, cy: Float, r: Float, col: Color) {
    val parts = listOf(Triple(0f, 0f, 1f), Triple(.7f, .15f, .8f), Triple(-.7f, .2f, .75f), Triple(.25f, -.3f, .7f))
    for ((dx, dy, s) in parts) {
        val c = Offset(cx + dx * r, cy + dy * r)
        val rad = r * s
        drawCircle(Brush.radialGradient(listOf(col, col.copy(alpha = 0f)), center = c, radius = rad), radius = rad, center = c)
    }
}

private fun DrawScope.drawScene(seeds: Seeds, sky: Sky, hour: Float, t: Float) {
    val w = size.width
    val h = size.height
    val (top, bottom) = skyColors(hour, sky)
    drawRect(Brush.verticalGradient(listOf(top, bottom)))

    val night = isNight(hour)
    val e = max(0f, elevation(hour))
    val clearish = sky == Sky.SOL || sky == Sky.NUBLADO

    if (night && sky == Sky.SOL) {
        for (s in seeds.stars) {
            val a = (.45f + .45f * sin(t * 1.5f + s.p)).coerceIn(0f, 1f)
            drawCircle(Color.White.copy(alpha = a), radius = s.r * density, center = Offset(s.x * w, s.y * h))
        }
    }

    if (!night && clearish) {
        val k = ((hour - 6f) / 12f).coerceIn(-.05f, 1.05f)
        val cx = w * (.1f + .8f * k)
        val cy = h * (.8f - .62f * sin(PI.toFloat() * k))
        val dim = if (sky == Sky.SOL) 1f else .45f
        val pulse = 1f + .06f * sin(t * 1.8f)
        val warm = Color(1f, (150f + e * 100f) / 255f, (70f + e * 130f) / 255f)
        val rad = h * .75f * pulse
        val center = Offset(cx, cy)
        drawCircle(
            Brush.radialGradient(
                0f to warm.copy(alpha = .9f * dim), .25f to warm.copy(alpha = .38f * dim), 1f to warm.copy(alpha = 0f),
                center = center, radius = rad
            ),
            radius = rad, center = center
        )
        if (sky == Sky.SOL && e > .3f) {
            val ray = Path().apply {
                moveTo(cx, cy); lineTo(cx + h * 1.2f, cy - h * .05f); lineTo(cx + h * 1.2f, cy + h * .05f); close()
            }
            rotate(t * 8.2f, center) {
                for (i in 0 until 12) rotate(i * 30f, center) { drawPath(ray, Color(0xFFFFF8D2).copy(alpha = .12f)) }
            }
        }
        drawCircle(
            Color(1f, min(255f, 150f + e * 100f + 60f) / 255f, min(255f, 70f + e * 130f + 80f) / 255f, dim),
            radius = min(w, h) * .085f, center = center
        )
    }

    if (night && clearish) {
        val hh = if (hour >= 18.4f) hour - 18.4f else hour + 5.6f
        val tt = hh / 11.2f
        val c = Offset(w * (.1f + .8f * tt), h * (.72f - .52f * sin(PI.toFloat() * tt)))
        val mr = min(w, h) * .075f
        val mo = if (sky == Sky.SOL) 1f else .5f
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFFDCE6FF).copy(alpha = .28f * mo), Color.Transparent), center = c, radius = mr * 4f),
            radius = mr * 4f, center = c
        )
        drawCircle(Color(0xFFF4F1DD).copy(alpha = mo), radius = mr, center = c)
        drawCircle(top.copy(alpha = mo), radius = mr * .9f, center = Offset(c.x + mr * .45f, c.y - mr * .2f))
    }

    val cc = cloudColor(sky, hour)
    for (c in seeds.clouds) {
        val r = c.rFrac * min(w, h * 2.2f)
        val span = w + r * 4f
        val cx = ((c.x * w + c.v * w * t) % span) - r * 2f
        cloudBlob(cx, c.y * h, r, cc)
    }

    if (seeds.drops.isNotEmpty()) {
        val col = if (sky == Sky.TORMENTA) Color(0xFFB9CDEB).copy(alpha = .6f) else Color(0xFFBED4F0).copy(alpha = .5f)
        val sw = (if (sky == Sky.TORMENTA) 1.3f else 1f) * density
        for (d in seeds.drops) {
            val l = d.len * h
            val y = ((d.y0 + d.speed * t) % 1f) * (h + l) - l
            val x0 = d.x * w - y * .25f
            val x = ((x0 % w) + w) % w
            drawLine(col, Offset(x, y), Offset(x - l * .25f, y + l), strokeWidth = sw)
        }
    }

    for (f in seeds.flakes) {
        val y = ((f.y0 + f.speed * t) % 1f) * h
        val x = f.x * w + sin(t * 1.5f + f.p) * 8f * density
        drawCircle(Color.White.copy(alpha = .9f), radius = f.r * density, center = Offset(x, y))
    }

    if (sky == Sky.TORMENTA) {
        val period = 3.4f
        val idx = floor(t / period).toInt()
        val phase = t - idx * period
        if (phase < .35f) {
            val fl = 1f - phase / .35f
            drawRect(Color(0xFFEBF2FF).copy(alpha = fl * .5f))
            val rnd = java.util.Random(idx.toLong() * 131L + 5L)
            var px = w * (.2f + rnd.nextFloat() * .6f)
            var py = h * .12f
            val bolt = Path().apply {
                moveTo(px, py)
                for (i in 0 until 7) {
                    px += (rnd.nextFloat() - .5f) * 50f * density
                    py += h * .11f
                    lineTo(px, py)
                }
            }
            drawPath(bolt, Color.White.copy(alpha = fl * .35f), style = Stroke(width = 7f * density, cap = StrokeCap.Round))
            drawPath(bolt, Color.White.copy(alpha = fl), style = Stroke(width = 2.6f * density, cap = StrokeCap.Round))
        }
    }

    // Sombras suaves arriba y abajo para que el texto blanco siempre se lea.
    drawRect(Brush.verticalGradient(listOf(Color(0x57081432), Color.Transparent), startY = 0f, endY = h * .55f))
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0x38000000)), startY = h * .4f, endY = h))
}
