package com.optimizador.core

/** Puntaje 0-100. Mismo cálculo antes y después para poder demostrar la mejora. */
object HealthScore {
    fun compute(s: DeviceSnapshot): Int {
        var score = 100

        // Almacenamiento: el mayor causante de lentitud en celulares viejos
        score -= when {
            s.storageUsedPct >= 95 -> 30
            s.storageUsedPct >= 90 -> 22
            s.storageUsedPct >= 80 -> 12
            else -> 0
        }
        // RAM libre
        score -= when {
            s.ramFreePct < 10 -> 20
            s.ramFreePct < 20 -> 12
            s.ramFreePct < 30 -> 5
            else -> 0
        }
        // Animaciones lentas hacen que todo se sienta más pesado
        if (s.animationScale >= 1f) score -= 8
        // Demasiadas apps instaladas
        if (s.installedAppCount > 120) score -= 8
        if (s.installedAppCount > 200) score -= 6

        return score.coerceIn(0, 100)
    }
}
