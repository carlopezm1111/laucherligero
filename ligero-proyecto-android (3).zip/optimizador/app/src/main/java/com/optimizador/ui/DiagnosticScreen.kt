package com.optimizador.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier

@Composable
fun DiagnosticScreen(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.scan() }
    val s = vm.snapshot

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        LText("Diagnóstico", 27, FontWeight.Bold)
        if (s == null) {
            LText("Midiendo tu celular…", 15, alpha = .8f)
        } else {
            LiquidPanel(tier, theme, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    LText("Salud del celular", 13, alpha = .8f)
                    LText("${vm.score}", 56, FontWeight.Bold, color = theme.highlight)
                    LText(
                        "RAM libre ${s.ramFreePct}% · Almacenamiento usado ${s.storageUsedPct}% · ${s.installedAppCount} apps",
                        13, alpha = .8f, align = TextAlign.Center
                    )
                }
            }
            if (vm.recommendations.isEmpty()) {
                LText("No encontramos problemas importantes. Tu celular está en buen estado.", 15)
            } else {
                LText("Qué puedes mejorar", 15, alpha = .8f)
                vm.recommendations.forEach { r ->
                    LiquidPanel(tier, theme, Modifier.fillMaxWidth(), androidx.compose.foundation.shape.RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            LText(r.title, 16, FontWeight.SemiBold)
                            LText(r.detail, 13, alpha = .8f)
                            LText("Impacto: ${r.impact.name.lowercase()}", 12, color = theme.highlight)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        GlassButton("Volver a medir", tier, theme) { vm.scan() }
        GlassButton("Dar permiso de uso de apps (opcional)", tier, theme) {
            ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        Spacer(Modifier.height(90.dp))
    }
}

@Composable
fun GlassButton(text: String, tier: UiTier, theme: LigeroTheme, onClick: () -> Unit) {
    LiquidPanel(tier, theme, Modifier.fillMaxWidth().heightIn(min = 52.dp).clickable(onClick = onClick),
        androidx.compose.foundation.shape.RoundedCornerShape(20.dp)) {
        Box(Modifier.fillMaxWidth().heightIn(min = 52.dp), contentAlignment = Alignment.Center) {
            LText(text, 15, FontWeight.SemiBold, align = TextAlign.Center, modifier = Modifier.padding(horizontal = 12.dp))
        }
    }
}
