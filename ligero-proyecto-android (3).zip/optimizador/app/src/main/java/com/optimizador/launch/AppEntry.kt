package com.optimizador.launch

import android.content.ComponentName
import android.content.Intent

/**
 * Una app lista para abrirse. El Intent ya está armado: al tocar el ícono
 * no hay que calcular nada, solo lanzarlo.
 */
data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val launchIntent: Intent,
    /** Texto en minúsculas y sin tildes, para buscar sin recalcular. */
    val searchKey: String
)
