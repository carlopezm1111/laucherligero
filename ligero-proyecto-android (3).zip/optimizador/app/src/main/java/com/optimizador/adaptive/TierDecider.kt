package com.optimizador.adaptive

/**
 * Lógica pura (sin Android) que decide cuándo cambiar de nivel.
 * Regla de oro: bajar rápido, subir despacio, y no volver a un nivel que acaba de fallar.
 */
class TierDecider(
    startTier: UiTier,
    private val maxTier: UiTier = startTier,
    private val nowMs: () -> Long = System::currentTimeMillis
) {
    var tier: UiTier = startTier
        private set

    private var badSeconds = 0
    private var goodSeconds = 0
    private var bannedTier: UiTier? = null
    private var bannedUntilMs = 0L

    /** Devuelve el nuevo nivel si hay que cambiar, o null si se queda igual. */
    fun onSample(s: FluiditySample): UiTier? {
        when {
            s.jankRatio > BAD_JANK -> { badSeconds++; goodSeconds = 0 }
            s.jankRatio < GOOD_JANK -> { goodSeconds++; badSeconds = 0 }
            else -> { badSeconds = 0 }
        }

        if (badSeconds >= SECONDS_TO_DOWNGRADE && tier != UiTier.LIGERO) {
            bannedTier = tier                       // este nivel falló: no volver pronto
            bannedUntilMs = nowMs() + BAN_MS
            return change(tier.lower())
        }

        if (goodSeconds >= SECONDS_TO_UPGRADE && tier.ordinal > maxTier.ordinal) {
            val next = tier.higher()
            val banned = next == bannedTier && nowMs() < bannedUntilMs
            if (!banned) return change(next)
        }
        return null
    }

    private fun change(new: UiTier): UiTier {
        tier = new
        badSeconds = 0
        goodSeconds = 0
        return new
    }

    private companion object {
        const val BAD_JANK = 0.15f          // más de 15% de fotogramas con tirón
        const val GOOD_JANK = 0.03f         // menos de 3% = fluido
        const val SECONDS_TO_DOWNGRADE = 2  // reacciona en 2 s
        const val SECONDS_TO_UPGRADE = 30   // exige 30 s fluidos para mejorar
        const val BAN_MS = 10 * 60 * 1000L  // 10 min sin reintentar el nivel que falló
    }
}
