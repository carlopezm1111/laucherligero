package com.optimizador.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier
import com.optimizador.engine.BoostState

/** El cohete: un toque libera memoria y limpia la caché. Mientras trabaja, tiembla y echa fuego. */
@Composable
fun RocketWidget(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    val running = vm.boostState is BoostState.Running
    val ink = LocalInk.current
    var flame = 0f
    var shake = 0f
    if (running) {
        val t = rememberInfiniteTransition(label = "cohete")
        val f by t.animateFloat(0.6f, 1.25f, infiniteRepeatable(tween(140, easing = LinearEasing), RepeatMode.Reverse), label = "llama")
        val s by t.animateFloat(-1.6f, 1.6f, infiniteRepeatable(tween(70), RepeatMode.Reverse), label = "temblor")
        flame = f
        shake = s
    }
    LiquidPanel(
        tier, theme,
        Modifier.size(54.dp).clickable(enabled = !running) { vm.boost() },
        CircleShape
    ) {
        Canvas(Modifier.fillMaxSize().padding(11.dp)) { drawRocket(ink, flame, shake, running) }
    }
}

private fun DrawScope.drawRocket(ink: Color, flame: Float, shake: Float, running: Boolean) {
    val w = size.width
    val h = size.height
    translate(left = shake * density, top = 0f) {
        if (running) {
            val fire = Path().apply {
                moveTo(.40f * w, .76f * h); lineTo(.5f * w, (.76f + .22f * flame) * h); lineTo(.60f * w, .76f * h); close()
            }
            drawPath(fire, Color(0xFFFF9A3D))
        }
        val body = Path().apply {
            moveTo(.5f * w, .02f * h)
            cubicTo(.82f * w, .22f * h, .80f * w, .58f * h, .68f * w, .74f * h)
            lineTo(.32f * w, .74f * h)
            cubicTo(.20f * w, .58f * h, .18f * w, .22f * h, .5f * w, .02f * h)
            close()
        }
        drawPath(body, ink)
        val left = Path().apply {
            moveTo(.32f * w, .56f * h); lineTo(.10f * w, .80f * h); lineTo(.34f * w, .74f * h); close()
        }
        val right = Path().apply {
            moveTo(.68f * w, .56f * h); lineTo(.90f * w, .80f * h); lineTo(.66f * w, .74f * h); close()
        }
        drawPath(left, ink.copy(alpha = .8f))
        drawPath(right, ink.copy(alpha = .8f))
        drawCircle(Color(0xFF4DA3FF), radius = .09f * w, center = Offset(.5f * w, .34f * h))
    }
}

/** Resultado del cohete: números medidos y el siguiente paso para limpiar más espacio. */
@Composable
fun BoostOverlay(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    val done = vm.boostState as? BoostState.Done ?: return
    val r = done.result
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        LiquidPanel(
            tier, theme,
            Modifier.navigationBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp).fillMaxWidth(),
            RoundedCornerShape(26.dp)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                LText("Listo", 18, FontWeight.Bold, color = theme.highlight)
                LText(
                    if (r.ramFreedMb > 0) "Memoria liberada: ${r.ramFreedMb} MB · libre ahora ${r.ramFreePct}%"
                    else "La memoria ya estaba bien aprovechada · libre ${r.ramFreePct}%",
                    14
                )
                LText("Caché de Ligero limpiada: ${r.cacheFreedMb} MB", 14)
                LText("Apps en segundo plano revisadas: ${r.appsChecked}", 14)
                LText("Espacio libre en el celular: ${"%.1f".format(r.storageFreeGb)} GB", 14)
                LText(
                    "Android no deja borrar la caché de otras apps desde aquí. Para limpiarla, abre el almacenamiento del sistema.",
                    12, alpha = .75f
                )
                GlassButton("Limpiar más espacio", tier, theme) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        // Si el celular no tiene esa pantalla, no pasa nada.
                    }
                    vm.dismissBoost()
                }
                GlassButton("Cerrar", tier, theme) { vm.dismissBoost() }
            }
        }
    }
}
