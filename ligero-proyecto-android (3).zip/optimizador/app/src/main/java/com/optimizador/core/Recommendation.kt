package com.optimizador.core

enum class Impact { ALTO, MEDIO, BAJO }

data class Recommendation(
    val id: String,
    val title: String,
    val detail: String,
    val impact: Impact,
    /** "Local" = calculada con reglas del propio celular. "Comunidad" = viene de otros celulares iguales. */
    val source: String = "Local"
)
