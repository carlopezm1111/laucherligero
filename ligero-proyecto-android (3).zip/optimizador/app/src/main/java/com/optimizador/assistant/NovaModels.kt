package com.optimizador.assistant

import com.optimizador.launch.AppEntry

/** Algo que Nova hará solo si la persona confirma. */
data class PendingAction(val yesLabel: String = "Sí, hazlo", val run: () -> Unit)

data class NovaMsg(val fromUser: Boolean, val text: String, val confirm: PendingAction? = null)

/** Pedido para que la pantalla de inicio abra una sección (section: 0 Ajustes, 1 Diagnóstico, 2 Motor, 3 Revive, 4 Privacidad, 5 Bienestar). */
data class NavRequest(val section: Int = -1, val clock: Boolean = false, val drawer: Boolean = false)

/** Aviso suave cuando una app llegó a su límite diario. */
data class FocusPrompt(val entry: AppEntry, val used: Int, val limit: Int)
