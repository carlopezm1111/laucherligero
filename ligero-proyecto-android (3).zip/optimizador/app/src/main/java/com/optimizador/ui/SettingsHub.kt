package com.optimizador.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.AdaptiveUiController
import com.optimizador.adaptive.UiTier

/**
 * Pantalla que queda a la izquierda del inicio (se abre deslizando hacia la derecha).
 * section: -1 menú, 0 Ajustes, 1 Diagnóstico, 2 Motor, 3 Revive tu celular, 4 Privacidad, 5 Bienestar.
 */
@Composable
fun SettingsHub(
    vm: LigeroViewModel,
    controller: AdaptiveUiController,
    tier: UiTier,
    theme: LigeroTheme,
    section: Int,
    onSection: (Int) -> Unit
) {
    if (section >= 0) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    .clickable { onSection(-1) }.padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LText("‹  Volver", 15, FontWeight.SemiBold, color = theme.highlight)
            }
            Box(Modifier.weight(1f)) {
                when (section) {
                    0 -> SettingsScreen(vm, controller, tier, theme)
                    1 -> DiagnosticScreen(vm, tier, theme)
                    2 -> EngineScreen(vm, controller, tier, theme)
                    3 -> ReviveScreen(vm, tier, theme)
                    4 -> PrivacyScreen(vm, tier, theme)
                    else -> WellbeingScreen(vm, tier, theme)
                }
            }
        }
    } else {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LText("Ligero", 27, FontWeight.Bold)
            LText("Desliza hacia la izquierda para volver al inicio", 13, alpha = .8f)
            Entrada("Revive tu celular", "Mide, acelera y te muestra el antes y el después", tier, theme) { onSection(3) }
            Entrada("Ajustes", "Fluidez, niveles, colores, temas, clima y actualizaciones", tier, theme) { onSection(0) }
            Entrada("Diagnóstico", "Mide tu celular y te dice qué puedes mejorar", tier, theme) { onSection(1) }
            Entrada("Motor de rendimiento", "Memoria, reglas automáticas y registro de eventos", tier, theme) { onSection(2) }
            Entrada("Privacidad", "Qué apps tienen cámara, micrófono o ubicación", tier, theme) { onSection(4) }
            Entrada("Bienestar", "Tu tiempo de uso y límites suaves por app", tier, theme) { onSection(5) }
            Box(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun Entrada(title: String, detail: String, tier: UiTier, theme: LigeroTheme, onClick: () -> Unit) {
    LiquidPanel(tier, theme, Modifier.fillMaxWidth().clickable { onClick() }, RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            LText(title, 18, FontWeight.Bold)
            LText(detail, 13, alpha = .8f)
        }
    }
}
