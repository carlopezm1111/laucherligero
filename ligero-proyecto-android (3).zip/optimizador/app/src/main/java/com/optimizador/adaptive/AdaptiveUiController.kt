package com.optimizador.adaptive

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Une el medidor con la lógica de decisión y expone el nivel actual a la interfaz.
 *
 * Uso (en la Activity del launcher):
 *   val controller = AdaptiveUiController(totalRamMb, display.refreshRate)
 *   onStart  -> controller.start()
 *   onStop   -> controller.stop()
 *   Compose  -> val tier by controller.tier.collectAsState()
 */
class AdaptiveUiController(totalRamMb: Long, refreshRateHz: Float) {

    val startTier = UiTier.initialFor(totalRamMb)
    private var decider = TierDecider(startTier = startTier, maxTier = startTier)

    private val _tier = MutableStateFlow(startTier)
    val tier: StateFlow<UiTier> = _tier.asStateFlow()

    private val _lastSample = MutableStateFlow<FluiditySample?>(null)
    val lastSample: StateFlow<FluiditySample?> = _lastSample.asStateFlow()

    /** Si es false, la persona eligió un nivel a mano y no se cambia solo. */
    var auto: Boolean = true

    private val monitor = FluidityMonitor(refreshRateHz) { sample ->
        _lastSample.value = sample
        if (auto) decider.onSample(sample)?.let { _tier.value = it }
    }

    /** Modo ultraligero: fuerza el nivel más simple. Al apagarlo vuelve al ajuste automático. */
    fun setUltraLight(on: Boolean) {
        if (on) {
            auto = false
            _tier.value = UiTier.LIGERO
        } else {
            auto = true
            decider = TierDecider(startTier = startTier, maxTier = startTier)
            _tier.value = startTier
        }
    }

    fun start() = monitor.start()
    fun stop() = monitor.stop()

    fun setManual(tier: UiTier) {
        auto = false
        _tier.value = tier
    }
}
