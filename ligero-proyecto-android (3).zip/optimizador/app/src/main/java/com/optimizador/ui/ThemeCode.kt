package com.optimizador.ui

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette

/**
 * Temas compartibles sin servidor: el tema completo viaja dentro de un texto corto
 * ("LT1|nombre|colores...") que se manda por cualquier chat y se pega en Ajustes.
 */
object ThemeCode {
    private val HEX = Regex("^[0-9A-Fa-f]{6}$")

    private fun hex(c: Color): String = "%06X".format(c.toArgb() and 0xFFFFFF)

    fun encode(t: LigeroTheme): String = listOf(
        "LT1", t.name.replace("|", " "), hex(t.base),
        hex(t.blobs[0]), hex(t.blobs[1]), hex(t.blobs[2]), hex(t.blobs[3]),
        hex(t.panel), hex(t.highlight), if (t.light) "1" else "0"
    ).joinToString("|")

    fun decode(code: String): LigeroTheme? {
        val p = code.trim().split("|")
        if (p.size != 10 || p[0] != "LT1") return null
        if ((2..8).any { !HEX.matches(p[it]) }) return null
        fun c(s: String) = Color(("FF$s").toLong(16))
        val blobs = listOf(c(p[3]), c(p[4]), c(p[5]), c(p[6]))
        val light = p[9] == "1"
        return LigeroTheme(
            name = p[1].take(18).ifBlank { "Tema" },
            base = c(p[2]), blobs = blobs, panel = c(p[7]), highlight = c(p[8]),
            light = light, rimA = blobs[0], rimB = blobs[1]
        )
    }

    /** Crea un tema con los colores dominantes de una foto (todo ocurre en el celular). */
    fun fromPhoto(bitmap: Bitmap, name: String): LigeroTheme {
        val pal = Palette.from(bitmap).maximumColorCount(16).generate()
        val vib = pal.getVibrantColor(0xFF4B6BFF.toInt())
        val light = pal.getLightVibrantColor(vib)
        val muted = pal.getMutedColor(vib)
        val lightMuted = pal.getLightMutedColor(muted)
        val dark = pal.getDarkMutedColor(0xFF0B1030.toInt())
        val base = lerp(Color(dark), Color.Black, 0.55f)
        return LigeroTheme(
            name = name,
            base = base,
            blobs = listOf(Color(vib), Color(light), Color(muted), Color(lightMuted)),
            panel = lerp(base, Color.White, 0.10f),
            highlight = lerp(Color(light), Color.White, 0.5f)
        )
    }
}
