package com.optimizador.adaptive

import android.view.Choreographer

/**
 * Mide la fluidez real de NUESTRA pantalla de inicio contando fotogramas.
 * Solo mide mientras está iniciado; llamar stop() cuando el launcher no es visible
 * para no gastar batería.
 *
 * @param refreshRateHz frecuencia de la pantalla (60, 90, 120...). Se obtiene de display.refreshRate.
 */
class FluidityMonitor(
    private val refreshRateHz: Float,
    private val onSample: (FluiditySample) -> Unit
) : Choreographer.FrameCallback {

    private val choreographer = Choreographer.getInstance()
    private val budgetNs = (1_000_000_000L / refreshRateHz).toLong()

    private var lastFrameNs = 0L
    private var windowStartNs = 0L
    private var frames = 0
    private var jankFrames = 0
    private var running = false

    fun start() {
        if (running) return
        running = true
        lastFrameNs = 0L
        windowStartNs = 0L
        frames = 0
        jankFrames = 0
        choreographer.postFrameCallback(this)
    }

    fun stop() {
        running = false
        choreographer.removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return

        if (lastFrameNs != 0L) {
            frames++
            if (frameTimeNanos - lastFrameNs > budgetNs * 3 / 2) jankFrames++
        } else {
            windowStartNs = frameTimeNanos
        }
        lastFrameNs = frameTimeNanos

        if (frameTimeNanos - windowStartNs >= ONE_SECOND_NS && frames > 0) {
            val seconds = (frameTimeNanos - windowStartNs) / ONE_SECOND_NS.toFloat()
            onSample(
                FluiditySample(
                    fps = (frames / seconds).toInt(),
                    jankRatio = jankFrames / frames.toFloat()
                )
            )
            windowStartNs = frameTimeNanos
            frames = 0
            jankFrames = 0
        }
        choreographer.postFrameCallback(this)
    }

    private companion object { const val ONE_SECOND_NS = 1_000_000_000L }
}
