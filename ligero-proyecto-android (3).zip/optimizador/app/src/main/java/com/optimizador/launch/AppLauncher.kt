package com.optimizador.launch

import android.app.ActivityOptions
import android.content.Context
import android.view.View

/**
 * Abre una app lo más rápido posible. Regla: en el toque no se calcula nada.
 * El Intent ya viene armado (AppEntry) y la animación arranca en el mismo instante.
 *
 * Nota honesta: esto acorta lo que pasa ANTES de que la app empiece a abrirse y
 * hace que se sienta inmediato. No acelera la app que se abre (WhatsApp, un juego...).
 */
class AppLauncher(private val context: Context) {

    /** Abre una app sin animación desde un ícono (lo usa Nova, que no toca ningún ícono). */
    fun openPlain(entry: AppEntry) {
        try {
            context.startActivity(entry.launchIntent)
        } catch (e: Exception) {
            // La app pudo desinstalarse justo ahora.
        }
    }

    /**
     * @param source vista del ícono tocado (en Compose: LocalView.current)
     * @param x,y,w,h posición y tamaño del ícono dentro de esa vista, en píxeles
     * @param animationScale 1f normal; viene de UiTier.animScale para respetar el nivel adaptativo
     */
    fun open(
        entry: AppEntry, source: View, x: Int, y: Int, w: Int, h: Int,
        animationScale: Float = 1f, animate: Boolean = true
    ) {
        // La animación nace en el ícono; el sistema la dibuja, no nuestro hilo principal.
        // Sin animaciones: la app aparece de golpe. Con animaciones: crece desde el ícono.
        val options = if (animate) ActivityOptions.makeScaleUpAnimation(source, x, y, w, h)
        else ActivityOptions.makeCustomAnimation(context, 0, 0)
        try {
            context.startActivity(entry.launchIntent, options.toBundle())
        } catch (e: Exception) {
            // La app pudo desinstalarse justo ahora; el AppIndex se refrescará solo.
        }
    }
}
