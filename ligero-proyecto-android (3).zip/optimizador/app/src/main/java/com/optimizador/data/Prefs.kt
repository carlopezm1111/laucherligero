package com.optimizador.data

import android.content.Context

/** Todo lo que el launcher recuerda: se guarda en el celular y sobrevive a cierres y actualizaciones. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("ligero", Context.MODE_PRIVATE)

    var themeIndex: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    var ultraLight: Boolean
        get() = sp.getBoolean("ultra", false)
        set(v) { sp.edit().putBoolean("ultra", v).apply() }

    var city: String
        get() = sp.getString("city", "") ?: ""
        set(v) { sp.edit().putString("city", v).apply() }

    var serverUrl: String
        get() = sp.getString("server", "") ?: ""
        set(v) { sp.edit().putString("server", v.trim().trimEnd('/')).apply() }

    var communityOptIn: Boolean
        get() = sp.getBoolean("community", false)
        set(v) { sp.edit().putBoolean("community", v).apply() }

    var textMode: Boolean
        get() = sp.getBoolean("textMode", false)
        set(v) { sp.edit().putBoolean("textMode", v).apply() }

    /** Identificador aleatorio del celular, solo para limitar las consultas diarias a la IA. No identifica a la persona. */
    val deviceId: String
        get() {
            var id = sp.getString("deviceId", null)
            if (id == null) {
                id = java.util.UUID.randomUUID().toString()
                sp.edit().putString("deviceId", id).apply()
            }
            return id
        }

    /** Rutina: cuántas veces abres cada app en cada momento del día (0 madrugada, 1 mañana, 2 tarde, 3 noche). */
    fun incRoutine(bucket: Int, key: String) {
        sp.edit().putInt("r:$bucket:$key", sp.getInt("r:$bucket:$key", 0) + 1).apply()
    }

    fun routineCounts(): Map<String, Int> =
        sp.all.filterKeys { it.startsWith("r:") }
            .mapKeys { it.key.removePrefix("r:") }
            .mapValues { (it.value as? Int) ?: 0 }

    /** Límites diarios por app, en minutos (bienestar digital). */
    fun limits(): Map<String, Int> =
        sp.all.filterKeys { it.startsWith("limit:") }
            .mapKeys { it.key.removePrefix("limit:") }
            .mapValues { (it.value as? Int) ?: 0 }

    fun setLimit(pkg: String, minutes: Int) {
        val e = sp.edit()
        if (minutes <= 0) e.remove("limit:$pkg") else e.putInt("limit:$pkg", minutes)
        e.apply()
    }

    var noAnim: Boolean
        get() = sp.getBoolean("noAnim", false)
        set(v) { sp.edit().putBoolean("noAnim", v).apply() }

    var autoUpdateCheck: Boolean
        get() = sp.getBoolean("autoUpdate", true)
        set(v) { sp.edit().putBoolean("autoUpdate", v).apply() }

    fun hasKey(key: String): Boolean = sp.contains(key)

    fun getList(key: String): List<String> =
        sp.getString(key, null)?.split("\n")?.filter { it.isNotEmpty() } ?: emptyList()

    fun putList(key: String, value: List<String>) {
        sp.edit().putString(key, value.joinToString("\n")).apply()
    }

    fun getString(key: String): String? = sp.getString(key, null)

    fun putString(key: String, value: String) {
        sp.edit().putString(key, value).apply()
    }

    fun incLaunch(key: String) {
        sp.edit().putInt("n:$key", sp.getInt("n:$key", 0) + 1).apply()
    }

    fun launchCounts(): Map<String, Int> =
        sp.all.filterKeys { it.startsWith("n:") }
            .mapKeys { it.key.removePrefix("n:") }
            .mapValues { (it.value as? Int) ?: 0 }
}
