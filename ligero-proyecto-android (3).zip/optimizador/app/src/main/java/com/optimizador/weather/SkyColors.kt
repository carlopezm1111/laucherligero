package com.optimizador.weather

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

private class Frame(val h: Float, val top: Color, val bottom: Color)

/** Colores del cielo despejado a lo largo del día: noche, amanecer, mañana, tarde, atardecer, crepúsculo. */
private val FRAMES = listOf(
    Frame(0f, Color(0xFF050A24), Color(0xFF16205A)),
    Frame(5f, Color(0xFF060B28), Color(0xFF1C2A66)),
    Frame(6.5f, Color(0xFF3A4A8C), Color(0xFFF29A76)),
    Frame(9f, Color(0xFF2E7FE0), Color(0xFF8CC8F5)),
    Frame(13f, Color(0xFF1C66CF), Color(0xFF5FA9EE)),
    Frame(16.5f, Color(0xFF3A74C8), Color(0xFFF2B56E)),
    Frame(18.25f, Color(0xFF5B3F8F), Color(0xFFFF8A55)),
    Frame(19.75f, Color(0xFF1B2150), Color(0xFF8E4B8A)),
    Frame(21.5f, Color(0xFF060B28), Color(0xFF1C2A66)),
    Frame(24f, Color(0xFF050A24), Color(0xFF16205A))
)

fun elevation(h: Float): Float = sin(PI.toFloat() * (h - 6f) / 12f)
fun daylight(h: Float): Float = 0.28f + 0.72f * max(0f, elevation(h))
fun isNight(h: Float): Boolean = h < 5.6f || h >= 18.4f

private fun Color.scaled(f: Float) = Color(red * f, green * f, blue * f, alpha)

private fun grey(sky: Sky): Triple<Color, Color, Float>? = when (sky) {
    Sky.NUBLADO -> Triple(Color(0xFF7D8A9E), Color(0xFFC6CDD8), .8f)
    Sky.LLUVIA -> Triple(Color(0xFF46526A), Color(0xFF7B8799), .9f)
    Sky.TORMENTA -> Triple(Color(0xFF171B29), Color(0xFF363E57), .95f)
    Sky.NIEVE -> Triple(Color(0xFF566788), Color(0xFFA9B7CC), .85f)
    Sky.SOL -> null
}

/** Color de arriba y de abajo del cielo para una hora (0 a 24) y un clima. */
fun skyColors(h: Float, sky: Sky): Pair<Color, Color> {
    var i = 0
    while (i < FRAMES.size - 2 && h >= FRAMES[i + 1].h) i++
    val a = FRAMES[i]
    val b = FRAMES[i + 1]
    val k = ((h - a.h) / (b.h - a.h)).coerceIn(0f, 1f)
    var top = lerp(a.top, b.top, k)
    var bottom = lerp(a.bottom, b.bottom, k)
    val g = grey(sky)
    if (g != null) {
        val f = 0.32f + 0.68f * daylight(h)
        top = lerp(top, g.first.scaled(f), g.third)
        bottom = lerp(bottom, g.second.scaled(f), g.third)
    }
    return top to bottom
}

/** Color de las nubes: se oscurecen de noche y se tiñen de naranja al atardecer. */
fun cloudColor(sky: Sky, h: Float): Color {
    val base = when (sky) {
        Sky.SOL -> Color(1f, 1f, 1f, .72f)
        Sky.NUBLADO -> Color(238 / 255f, 241 / 255f, 247 / 255f, .95f)
        Sky.LLUVIA -> Color(122 / 255f, 132 / 255f, 150 / 255f, .92f)
        Sky.TORMENTA -> Color(78 / 255f, 88 / 255f, 112 / 255f, .95f)
        Sky.NIEVE -> Color(236 / 255f, 241 / 255f, 249 / 255f, .8f)
    }
    val f = 0.3f + 0.7f * daylight(h)
    val shaded = Color(base.red * f, base.green * f, base.blue * f, base.alpha)
    val e = max(0f, elevation(h))
    val warm = if (!isNight(h) && e < .3f) .25f * (1f - e / .3f) else 0f
    return lerp(shaded, Color(1f, 170 / 255f, 110 / 255f, base.alpha), warm)
}
