package com.optimizador.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier

private val OPCIONES = listOf(0, 15, 30, 60, 120)

/** Bienestar: tiempo de uso de hoy, límites suaves por app y modo texto sin íconos. */
@Composable
fun WellbeingScreen(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    val ctx = LocalContext.current
    val apps by vm.index.apps.collectAsState()
    LaunchedEffect(Unit) { vm.refreshUsage() }
    val usage = vm.usageToday
    val total = usage.values.sum()

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        LText("Bienestar", 27, FontWeight.Bold)
        LText("Tu tiempo de uso de hoy y límites suaves: Ligero te avisa, nunca te bloquea.", 14, alpha = .8f)

        if (usage.isEmpty()) {
            LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    LText("Falta un permiso", 15, FontWeight.SemiBold)
                    LText(
                        "Para ver cuánto usas cada app, Android pide que actives «Acceso a datos de uso» para Ligero. " +
                            "Todo se calcula en tu celular.",
                        13, alpha = .85f
                    )
                }
            }
            GlassButton("Dar el permiso", tier, theme) {
                ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } else {
            LiquidPanel(tier, theme, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    LText("Hoy en total", 13, alpha = .8f)
                    LText("${total / 60} h ${total % 60} min", 34, FontWeight.Bold, color = theme.highlight)
                }
            }
            usage.entries.sortedByDescending { it.value }.mapNotNull { e ->
                apps.firstOrNull { it.packageName == e.key }?.let { it to e.value }
            }.take(8).forEach { (app, minutes) ->
                val limit = vm.limits[app.packageName] ?: 0
                LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            LText(app.label, 15, FontWeight.SemiBold, maxLines = 1)
                            LText("$minutes min hoy", 12, alpha = .8f)
                        }
                        Box(
                            Modifier.heightIn(min = 44.dp).clickable {
                                val next = OPCIONES[(OPCIONES.indexOf(limit).coerceAtLeast(0) + 1) % OPCIONES.size]
                                vm.setLimit(app.packageName, next)
                            }.padding(horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            LText(if (limit > 0) "Límite: $limit min" else "Sin límite", 13, FontWeight.Bold, color = theme.highlight)
                        }
                    }
                }
            }
        }

        Interruptor(
            "Modo texto", "Muestra solo los nombres de las apps, sin íconos: menos distracciones",
            vm.textMode, tier, theme
        ) { vm.setTextMode(it) }
        Box(Modifier.height(90.dp))
    }
}
