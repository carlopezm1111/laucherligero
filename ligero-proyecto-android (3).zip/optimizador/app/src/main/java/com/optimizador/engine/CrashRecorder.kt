package com.optimizador.engine

import android.content.Context

/**
 * Recuperación automática: si la app se cierra por un error, lo anota antes de morir.
 * Android vuelve a abrir el launcher solo, y como todo (orden de apps, dock, ajustes)
 * está guardado en el celular, la pantalla vuelve igual que estaba.
 */
object CrashRecorder {
    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                app.getSharedPreferences("ligero", Context.MODE_PRIVATE).edit()
                    .putString("crash", "${System.currentTimeMillis()}|${error.javaClass.simpleName}")
                    .commit()
            } catch (_: Throwable) {
                // Nunca hay que fallar dentro del manejador de errores.
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Devuelve el último error anotado (una sola vez) o null si todo estuvo bien. */
    fun consume(context: Context): String? {
        val sp = context.getSharedPreferences("ligero", Context.MODE_PRIVATE)
        val crash = sp.getString("crash", null)
        if (crash != null) sp.edit().remove("crash").apply()
        return crash
    }
}
