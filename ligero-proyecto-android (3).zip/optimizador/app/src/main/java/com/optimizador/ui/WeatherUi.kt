package com.optimizador.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier
import com.optimizador.weather.Sky
import com.optimizador.weather.WeatherScene
import com.optimizador.weather.isNight
import com.optimizador.weather.label
import kotlinx.coroutines.delay
import java.time.LocalDateTime

@Composable
fun rememberNow(): State<LocalDateTime> = produceState(LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(30_000)
    }
}

/** Widget del clima: el cielo se anima por dentro y cambia con la hora y el clima. */
@Composable
fun WeatherWidget(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme, hour: Float, onClick: () -> Unit) {
    val w = vm.weather
    val sky = w?.sky ?: Sky.SOL
    val night = isNight(hour)
    val animate = tier == UiTier.COMPLETO && !vm.noAnim

    LiquidPanel(
        tier, theme,
        Modifier.fillMaxWidth().height(112.dp).clickable { onClick() },
        RoundedCornerShape(28.dp)
    ) {
        WeatherScene(sky, hour, animate, Modifier.fillMaxSize())
        Row(
            Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                LText(if (w != null) "${w.tempC}°" else "--°", 42, FontWeight.Light, color = Color.White)
                LText(sky.label(night), 15, FontWeight.SemiBold, color = Color.White)
                if (w != null) LText("Máx ${w.maxC}° · Mín ${w.minC}°", 12, color = Color.White, alpha = .9f)
            }
            Column(horizontalAlignment = Alignment.End) {
                LText(
                    w?.city ?: "Elige tu ciudad en Ajustes", 12, color = Color.White,
                    align = TextAlign.End, modifier = Modifier.padding(start = 24.dp)
                )
            }
        }
    }
}
