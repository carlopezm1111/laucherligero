package com.optimizador.weather

enum class Sky { SOL, NUBLADO, LLUVIA, TORMENTA, NIEVE }

data class WeatherInfo(
    val city: String,
    val tempC: Int,
    val maxC: Int,
    val minC: Int,
    val sky: Sky,
    val isDay: Boolean,
    val updatedAt: Long
)

/** Traduce el código de clima internacional (WMO) que entrega Open-Meteo a nuestros 5 climas. */
fun skyFromWmo(code: Int): Sky = when (code) {
    0, 1 -> Sky.SOL
    2, 3, 45, 48 -> Sky.NUBLADO
    in 51..67, in 80..82 -> Sky.LLUVIA
    in 71..77, 85, 86 -> Sky.NIEVE
    95, 96, 99 -> Sky.TORMENTA
    else -> Sky.NUBLADO
}

fun Sky.label(night: Boolean): String = when (this) {
    Sky.SOL -> if (night) "Despejado" else "Soleado"
    Sky.NUBLADO -> "Nublado"
    Sky.LLUVIA -> "Lluvia"
    Sky.TORMENTA -> "Tormenta eléctrica"
    Sky.NIEVE -> "Nevada"
}
