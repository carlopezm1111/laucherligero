package com.optimizador.weather

import android.content.Context
import com.optimizador.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

/**
 * Clima desde Open-Meteo (gratis, sin clave). Solo se envía el NOMBRE de la ciudad que escribe
 * la persona: la app no usa la ubicación del celular. Nota: Open-Meteo es gratis para uso no
 * comercial; si Ligero se vende, hay que revisar sus condiciones.
 */
class WeatherRepository(private val context: Context, private val prefs: Prefs) {

    suspend fun fetch(city: String): WeatherInfo? = withContext(Dispatchers.IO) {
        try {
            val q = URLEncoder.encode(city, "UTF-8")
            val geo = getJson("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=es")
            val place = geo.optJSONArray("results")?.optJSONObject(0) ?: return@withContext null
            val lat = place.getDouble("latitude")
            val lon = place.getDouble("longitude")
            val name = place.optString("name", city)

            val w = getJson(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code,is_day" +
                    "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"
            )
            val cur = w.getJSONObject("current")
            val daily = w.getJSONObject("daily")
            WeatherInfo(
                city = name,
                tempC = cur.getDouble("temperature_2m").roundToInt(),
                maxC = daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                minC = daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
                sky = skyFromWmo(cur.getInt("weather_code")),
                isDay = cur.getInt("is_day") == 1,
                updatedAt = System.currentTimeMillis()
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun getJson(address: String): JSONObject {
        val conn = URL(address).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        return JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
    }

    fun save(info: WeatherInfo) {
        val j = JSONObject()
            .put("city", info.city).put("t", info.tempC).put("max", info.maxC).put("min", info.minC)
            .put("sky", info.sky.name).put("day", info.isDay).put("at", info.updatedAt)
        prefs.putString("weather", j.toString())
    }

    fun saved(): WeatherInfo? {
        val raw = prefs.getString("weather") ?: return null
        return try {
            val j = JSONObject(raw)
            WeatherInfo(
                j.getString("city"), j.getInt("t"), j.getInt("max"), j.getInt("min"),
                Sky.valueOf(j.getString("sky")), j.getBoolean("day"), j.getLong("at")
            )
        } catch (e: Exception) {
            null
        }
    }
}
