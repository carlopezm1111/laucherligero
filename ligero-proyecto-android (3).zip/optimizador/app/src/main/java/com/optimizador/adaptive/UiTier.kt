package com.optimizador.adaptive

/** Los tres niveles de interfaz del diseño. De más bonito a más ligero. */
enum class UiTier(
    val blurDp: Int,        // desenfoque del vidrio (0 = paneles sólidos)
    val glass: Boolean,     // vidrio translúcido sí/no
    val animScale: Float    // 1f = animaciones completas
) {
    COMPLETO(blurDp = 24, glass = true, animScale = 1f),
    EQUILIBRADO(blurDp = 10, glass = true, animScale = 0.8f),
    LIGERO(blurDp = 0, glass = false, animScale = 0.5f);

    fun lower(): UiTier = entries.getOrElse(ordinal + 1) { this }
    fun higher(): UiTier = entries.getOrElse(ordinal - 1) { this }

    companion object {
        /** Punto de partida según la RAM (Android reporta menos que la RAM comercial). */
        fun initialFor(totalRamMb: Long): UiTier = when {
            totalRamMb >= 7_000 -> COMPLETO
            totalRamMb >= 3_000 -> EQUILIBRADO
            else -> LIGERO
        }
    }
}
