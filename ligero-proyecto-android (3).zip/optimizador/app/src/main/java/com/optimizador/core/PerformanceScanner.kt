package com.optimizador.core

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings

/**
 * Lee el estado del celular usando solo APIs públicas de Android.
 * Para la lista de apps activas hace falta que la persona conceda
 * "Acceso a datos de uso" (PACKAGE_USAGE_STATS) en Ajustes.
 */
class PerformanceScanner(private val context: Context) {

    fun scan(): DeviceSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }

        val stat = StatFs(Environment.getDataDirectory().path)
        val totalStorage = stat.totalBytes / MB
        val freeStorage = stat.availableBytes / MB

        val animScale = Settings.Global.getFloat(
            context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f
        )

        return DeviceSnapshot(
            model = Build.MODEL,
            androidSdk = Build.VERSION.SDK_INT,
            totalRamMb = mem.totalMem / MB,
            freeRamMb = mem.availMem / MB,
            totalStorageMb = totalStorage,
            freeStorageMb = freeStorage,
            animationScale = animScale,
            installedAppCount = context.packageManager.getInstalledApplications(0).size,
            heavyBackgroundApps = recentlyActiveApps()
        )
    }

    /** Apps usadas en las últimas 24 h, como aproximación a "corren en segundo plano". */
    private fun recentlyActiveApps(): List<String> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        return usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - DAY_MS, now)
            .orEmpty()
            .filter { it.totalTimeInForeground > 0 }
            .sortedByDescending { it.totalTimeInForeground }
            .take(7)
            .map { it.packageName }
    }

    private companion object {
        const val MB = 1024L * 1024L
        const val DAY_MS = 24L * 60 * 60 * 1000
    }
}
