package com.optimizador.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier

/** Chequeo de privacidad: qué apps tienen permisos delicados concedidos. Solo informa; tú decides qué quitar. */
@Composable
fun PrivacyScreen(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.scanPrivacy() }
    val list = vm.privacyApps

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        LText("Privacidad", 27, FontWeight.Bold)
        LText("Qué apps tienen permisos delicados. Ligero solo los muestra: tú decides cuáles quitar.", 14, alpha = .8f)
        if (list == null) {
            LText("Revisando tus apps…", 15, alpha = .8f)
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("Micrófono", list.count { "Micrófono" in it.perms }, tier, theme, Modifier.weight(1f))
                Stat("Cámara", list.count { "Cámara" in it.perms }, tier, theme, Modifier.weight(1f))
                Stat("Ubicación siempre", list.count { "Ubicación siempre" in it.perms }, tier, theme, Modifier.weight(1f))
            }
            if (list.isEmpty()) LText("No encontré apps con permisos delicados concedidos.", 14)
            list.take(25).forEach { app ->
                LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            LText(app.label, 15, FontWeight.SemiBold, maxLines = 1)
                            LText(app.perms.joinToString(" · "), 12, alpha = .8f)
                        }
                        Box(
                            Modifier.padding(start = 10.dp).heightInMin().clickable {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            },
                            contentAlignment = Alignment.Center
                        ) { LText("Revisar", 13, FontWeight.Bold, color = theme.highlight) }
                    }
                }
            }
        }
        Box(Modifier.height(90.dp))
    }
}

private fun Modifier.heightInMin(): Modifier = this.then(Modifier.padding(vertical = 10.dp))

@Composable
private fun Stat(label: String, n: Int, tier: UiTier, theme: LigeroTheme, modifier: Modifier) {
    LiquidPanel(tier, theme, modifier, RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            LText("$n", 26, FontWeight.Bold, color = theme.highlight)
            LText(label, 12, alpha = .85f)
        }
    }
}
