package com.optimizador.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import android.provider.AlarmClock
import com.optimizador.assistant.Quick
import com.optimizador.assistant.QuickAnswers
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier
import com.optimizador.key
import com.optimizador.launch.AppEntry

private val AJUSTES_RAPIDOS = listOf(
    "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
    "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
    "Pantalla" to Settings.ACTION_DISPLAY_SETTINGS,
    "Sonido" to Settings.ACTION_SOUND_SETTINGS,
    "Batería" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
    "Almacenamiento" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS
)

private fun inicial(e: AppEntry): String =
    e.searchKey.firstOrNull()?.takeIf { it.isLetter() }?.uppercaseChar()?.toString() ?: "#"

/** Cajón de apps: lista por letras, apps sugeridas y buscador que también encuentra ajustes del sistema. */
@Composable
fun DrawerScreen(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val apps by vm.index.apps.collectAsState()
    var query by remember { mutableStateOf("") }
    val hiddenKeys = vm.hidden.toList()
    val counts = vm.launchCounts

    val results = remember(apps, hiddenKeys, query) {
        vm.index.search(query).filter { it.key() !in hiddenKeys }
    }
    val routine = remember(apps, hiddenKeys, vm.routineCounts) { vm.suggestedNow(apps) }
    val suggested = remember(apps, hiddenKeys, counts, routine) { if (routine.isNotEmpty()) routine else vm.suggested(apps) }
    val quick = remember(query) { QuickAnswers.answer(query) }
    val settingsMatches = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) emptyList() else AJUSTES_RAPIDOS.filter { it.first.lowercase().contains(q) }
    }
    val sections = remember(results) {
        results.groupBy { inicial(it) }.toSortedMap(compareBy<String> { if (it == "#") "~" else it })
    }

    Box(
        Modifier.fillMaxSize()
            .background(theme.base.copy(alpha = if (tier.glass) 0.94f else 1f))
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
            Box(
                Modifier.fillMaxWidth().height(36.dp).clickable { onClose() },
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(width = 44.dp, height = 5.dp).background(LocalInk.current.copy(.5f), RoundedCornerShape(3.dp)))
            }

            LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(50)) {
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = LocalInk.current, fontSize = 16.sp),
                    cursorBrush = SolidColor(LocalInk.current),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 15.dp),
                    decorationBox = { inner ->
                        if (query.isEmpty()) LText("Escribe para buscar", 16, alpha = .7f)
                        inner()
                    }
                )
            }
            Spacer(Modifier.height(10.dp))

            settingsMatches.forEach { (name, action) ->
                GlassButton("Ajustes: $name", tier, theme) {
                    try {
                        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        // Algunos celulares no tienen esa pantalla de ajustes.
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            quick?.let { q ->
                fun openClock(i: Intent) {
                    try {
                        ctx.startActivity(i.putExtra(AlarmClock.EXTRA_SKIP_UI, false).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        // Sin app de reloj: no se hace nada.
                    }
                }
                when (q) {
                    is Quick.Answer -> LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                        LText(q.title, 20, FontWeight.SemiBold, modifier = Modifier.padding(18.dp))
                    }
                    is Quick.Timer -> GlassButton("${q.label}: toca para abrir el reloj", tier, theme) {
                        openClock(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, q.seconds))
                    }
                    is Quick.Alarm -> GlassButton("Alarma a las ${"%d:%02d".format(q.hour, q.minute)}: toca para abrir el reloj", tier, theme) {
                        openClock(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, q.hour).putExtra(AlarmClock.EXTRA_MINUTES, q.minute))
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            if (query.isEmpty() && suggested.isNotEmpty()) {
                LText(if (routine.isNotEmpty()) "Para ${vm.bucketName()}" else "Sugeridas", 13, alpha = .8f)
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    suggested.forEach { AppIcon(it, vm, modifier = Modifier.weight(1f)) }
                    repeat(4 - suggested.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                contentPadding = PaddingValues(bottom = 40.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (query.isNotEmpty()) {
                    items(results, key = { it.key() }) { AppIcon(it, vm, modifier = Modifier.padding(vertical = 8.dp)) }
                } else {
                    sections.forEach { (letter, list) ->
                        item(key = "h$letter", span = { GridItemSpan(maxLineSpan) }) {
                            LText(letter, 13, FontWeight.Bold, color = theme.highlight, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                        }
                        items(list, key = { it.key() }) { AppIcon(it, vm, modifier = Modifier.padding(vertical = 8.dp)) }
                    }
                }
            }
        }
    }
}
