package com.optimizador.engine

/** Resultado de "Revive tu celular": medido antes y después de aplicar el plan. */
data class ReviveReport(
    val scoreBefore: Int,
    val scoreAfter: Int,
    val ramFreeBefore: Int,
    val ramFreeAfter: Int,
    val storageFreeGb: Float,
    val actions: List<String>,
    val manualSteps: List<String>
)

sealed interface ReviveState {
    data object Idle : ReviveState
    data class Running(val step: String) : ReviveState
    data class Done(val report: ReviveReport) : ReviveState
}
