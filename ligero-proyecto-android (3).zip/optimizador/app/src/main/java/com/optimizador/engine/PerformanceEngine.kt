package com.optimizador.engine

import android.app.ActivityManager
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.optimizador.data.EngineLog

/**
 * RAM inteligente: vigila la memoria libre. Si baja demasiado, libera la caché de íconos
 * y pausa las tareas secundarias (como buscar actualizaciones); cuando se recupera, las reanuda.
 */
class PerformanceEngine(
    private val context: Context,
    private val log: EngineLog,
    private val onLowMemory: () -> Unit
) {
    var memFreePct by mutableIntStateOf(100)
    var lowMemory by mutableStateOf(false)

    fun sample() {
        val am = context.getSystemService(ActivityManager::class.java)
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        if (info.totalMem <= 0) return
        memFreePct = (info.availMem * 100 / info.totalMem).toInt()

        val low = info.lowMemory || memFreePct < LOW_PCT
        if (low && !lowMemory) {
            lowMemory = true
            onLowMemory()
            log.add("Poca memoria: liberó la caché de íconos y pausó tareas secundarias")
        } else if (!low && lowMemory && memFreePct > RECOVER_PCT) {
            lowMemory = false
            log.add("Memoria recuperada: reanudó las tareas")
        }
    }

    private companion object {
        const val LOW_PCT = 12
        const val RECOVER_PCT = 18
    }
}
