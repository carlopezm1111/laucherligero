package com.optimizador.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier

/** Aviso suave cuando una app llegó a su límite diario: se puede abrir igual. */
@Composable
fun FocusOverlay(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    val p = vm.focusPrompt ?: return
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .5f)).clickable { vm.focusPrompt = null },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(32.dp).fillMaxWidth()
                .background(theme.panel.copy(alpha = 0.97f), RoundedCornerShape(24.dp))
                .border(1.dp, Color.White.copy(alpha = .25f), RoundedCornerShape(24.dp))
                .clickable { }
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LText("Llevas ${p.used} min hoy en ${p.entry.label}", 17, FontWeight.Bold)
            LText("Tu límite es de ${p.limit} min. ¿La abres igual?", 14, alpha = .85f)
            GlassButton("Abrir igual", tier, theme) { vm.openAnyway(p.entry) }
            GlassButton("Mejor no", tier, theme) { vm.focusPrompt = null }
        }
    }
}
