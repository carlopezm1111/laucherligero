package com.optimizador.launch

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.scale
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalViewConfiguration

/**
 * Toque sin espera para los íconos del launcher.
 *
 * Por qué existe: dentro de contenedores que se desplazan, Android espera un momento
 * (~100 ms) antes de mostrar que tocaste, por si en realidad ibas a deslizar.
 * Aquí el efecto de "presionado" aparece en el mismo instante en que el dedo toca,
 * y la app se abre en cuanto el dedo se levanta, sin ningún otro trabajo en medio.
 *
 * Si el dedo se mueve más que el umbral del sistema, se cancela y se deja deslizar.
 */
fun Modifier.instantTap(onTap: () -> Unit): Modifier = composed {
    var pressed by remember { mutableStateOf(false) }
    val slop = LocalViewConfiguration.current.touchSlop

    this
        .scale(if (pressed) 0.9f else 1f)
        .pointerInput(onTap) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                pressed = true                         // feedback inmediato
                var moved = 0f
                var tapped = false
                while (true) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val change = event.changes.firstOrNull { it.id == down.id } ?: break
                    moved += change.positionChange().getDistance()
                    if (moved > slop) break            // era un deslizamiento
                    if (change.changedToUp()) { tapped = true; break }
                }
                pressed = false
                if (tapped) onTap()                    // abre al instante
            }
        }
}
