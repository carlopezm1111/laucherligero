package com.optimizador.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier
import com.optimizador.key

/** Menú que sale al mantener pulsada una app. */
@Composable
fun AppMenu(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    val entry = vm.menuFor ?: return
    val ctx = LocalContext.current
    val k = entry.key()
    val inHome = k in vm.home
    val inDock = k in vm.dock

    fun close() { vm.menuFor = null }
    fun go(intent: Intent) {
        try {
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // Si el sistema no puede abrir esa pantalla, no hacemos nada.
        }
        close()
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .5f)).clickable { close() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.padding(32.dp).fillMaxWidth()
                .background(theme.panel.copy(alpha = 0.97f), RoundedCornerShape(24.dp))
                .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(24.dp))
                .clickable { }
        ) {
            Column(Modifier.padding(vertical = 10.dp)) {
                LText(entry.label, 18, FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
                Fila(if (inHome) "Quitar de inicio" else "Añadir a inicio") { vm.toggleHome(k); close() }
                Fila(if (inDock) "Quitar del dock" else "Añadir al dock") { vm.toggleDock(k); close() }
                Fila("Ocultar") { vm.hide(k); close() }
                Fila("Información de la app") {
                    go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${entry.packageName}")))
                }
                Fila("Desinstalar") {
                    go(Intent(Intent.ACTION_DELETE, Uri.parse("package:${entry.packageName}")))
                }
            }
        }
    }
}

@Composable
private fun Fila(text: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().heightIn(min = 52.dp).clickable { onClick() },
        contentAlignment = Alignment.CenterStart
    ) {
        LText(text, 16, modifier = Modifier.padding(horizontal = 20.dp))
    }
}
