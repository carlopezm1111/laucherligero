package com.optimizador.launch

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalViewConfiguration
import kotlinx.coroutines.withTimeoutOrNull

private enum class Gesto { TOQUE, CANCELADO }

/**
 * Toque sin espera, mantener pulsado y arrastrar.
 * - El efecto de "presionado" aparece al instante.
 * - Al levantar el dedo se llama onTap sin ningún trabajo extra.
 * - Si se mantiene pulsado, vibra. Sin arrastre habilitado se llama onLongPress enseguida.
 *   Con arrastre habilitado: si el dedo se mueve empieza el arrastre (onDragStart, onDrag, onDragEnd);
 *   si se suelta sin moverse se llama onLongPress (el menú de la app).
 * - Si el dedo se mueve antes del tiempo de pulsación larga, se cancela y deja deslizar.
 *
 * origin() es la posición del elemento en la pantalla: se suma a la del dedo para dar
 * coordenadas globales al arrastre.
 */
fun Modifier.launcherTap(
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    dragEnabled: Boolean = false,
    origin: () -> Offset = { Offset.Zero },
    onDragStart: (Offset) -> Unit = {},
    onDrag: (Offset) -> Unit = {},
    onDragEnd: () -> Unit = {}
): Modifier = composed {
    var pressed by remember { mutableStateOf(false) }
    val tap by rememberUpdatedState(onTap)
    val long by rememberUpdatedState(onLongPress)
    val originNow by rememberUpdatedState(origin)
    val dragStart by rememberUpdatedState(onDragStart)
    val dragMove by rememberUpdatedState(onDrag)
    val dragEnd by rememberUpdatedState(onDragEnd)
    val config = LocalViewConfiguration.current
    val haptic = LocalHapticFeedback.current

    this
        .scale(if (pressed) 0.9f else 1f)
        .pointerInput(dragEnabled) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                pressed = true
                var moved = 0f
                val result = withTimeoutOrNull(config.longPressTimeoutMillis) {
                    var out: Gesto? = null
                    while (out == null) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val change = event.changes.firstOrNull { it.id == down.id }
                        if (change == null) {
                            out = Gesto.CANCELADO
                        } else {
                            moved += change.positionChange().getDistance()
                            if (moved > config.touchSlop) out = Gesto.CANCELADO
                            else if (change.changedToUp()) out = Gesto.TOQUE
                        }
                    }
                    out
                }
                pressed = false
                when (result) {
                    Gesto.TOQUE -> tap()
                    null -> {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (!dragEnabled) {
                            long()
                            do {
                                val e = awaitPointerEvent(PointerEventPass.Initial)
                            } while (e.changes.any { it.pressed })
                        } else {
                            var dragging = false
                            var travelled = 0f
                            var done = false
                            while (!done) {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                                val change = event.changes.firstOrNull { it.id == down.id }
                                if (change == null) {
                                    done = true
                                } else if (!change.pressed) {
                                    done = true
                                    if (dragging) {
                                        dragging = false
                                        dragEnd()
                                    } else {
                                        long()
                                    }
                                    change.consume()
                                } else {
                                    travelled += change.positionChange().getDistance()
                                    if (!dragging && travelled > config.touchSlop) {
                                        dragging = true
                                        dragStart(originNow() + change.position)
                                    }
                                    if (dragging) dragMove(originNow() + change.position)
                                    change.consume()
                                }
                            }
                            if (dragging) dragEnd()
                        }
                    }
                    Gesto.CANCELADO -> Unit
                }
            }
        }
}
