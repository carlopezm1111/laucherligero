package com.optimizador.core

/**
 * Lo único que saldría del celular hacia el servidor: datos técnicos
 * anónimos, sin nombre, sin cuenta, sin lista de apps personales.
 * La persona debe aceptarlo de forma explícita (opt-in).
 */
data class CommunityReport(
    val model: String,
    val androidSdk: Int,
    val totalRamMb: Long,
    val scoreBefore: Int,
    val scoreAfter: Int,
    val appliedRecommendationIds: List<String>
)
