package com.optimizador.privacy

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager

data class AppPrivacy(val label: String, val packageName: String, val perms: List<String>)

/**
 * Chequeo de privacidad: lista qué apps instaladas tienen CONCEDIDOS permisos delicados
 * (cámara, micrófono, ubicación, contactos, SMS, llamadas). Solo mira; quitar un permiso
 * lo hace la persona en los ajustes de la app, a donde Ligero la lleva con un toque.
 */
class PrivacyScanner(private val context: Context) {

    private val sensitive = mapOf(
        "android.permission.CAMERA" to "Cámara",
        "android.permission.RECORD_AUDIO" to "Micrófono",
        "android.permission.ACCESS_FINE_LOCATION" to "Ubicación precisa",
        "android.permission.ACCESS_COARSE_LOCATION" to "Ubicación aproximada",
        "android.permission.ACCESS_BACKGROUND_LOCATION" to "Ubicación siempre",
        "android.permission.READ_CONTACTS" to "Contactos",
        "android.permission.READ_SMS" to "Mensajes SMS",
        "android.permission.READ_CALL_LOG" to "Registro de llamadas"
    )

    fun scan(): List<AppPrivacy> {
        val pm = context.packageManager
        val result = mutableListOf<AppPrivacy>()
        val packages = try {
            pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        } catch (e: Exception) {
            return emptyList()
        }
        for (info in packages) {
            val app = info.applicationInfo ?: continue
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            val req = info.requestedPermissions ?: continue
            val flags = info.requestedPermissionsFlags ?: continue
            val granted = mutableListOf<String>()
            for (i in req.indices) {
                val label = sensitive[req[i]] ?: continue
                if ((flags[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) granted.add(label)
            }
            if (granted.isNotEmpty()) {
                result.add(AppPrivacy(app.loadLabel(pm).toString(), info.packageName, granted.distinct()))
            }
        }
        return result.sortedByDescending { it.perms.size }
    }
}
