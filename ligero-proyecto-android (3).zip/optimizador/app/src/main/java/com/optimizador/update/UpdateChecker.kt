package com.optimizador.update

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object UpdateConfig {
    /** Repositorio de GitHub donde se publican las versiones. Si lo renombras, cámbialo aquí. */
    const val REPO = "carlopezm1111/laucherligero"
}

sealed interface UpdateState {
    data object Idle : UpdateState
    data object Checking : UpdateState
    data object UpToDate : UpdateState
    data class Available(val version: String, val url: String) : UpdateState
    data object Downloading : UpdateState
    data class Failed(val reason: String) : UpdateState
}

/**
 * Solo hace UNA consulta a la página de versiones de GitHub. No envía ningún dato de la persona.
 * El número de versión es el número al final de la etiqueta (v0.2.7 -> 7) y se compara con
 * el versionCode instalado.
 */
class UpdateChecker(private val context: Context) {

    suspend fun check(): UpdateState = withContext(Dispatchers.IO) {
        try {
            val url = URL("https://api.github.com/repos/${UpdateConfig.REPO}/releases/latest")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            if (conn.responseCode != 200) {
                return@withContext UpdateState.Failed("Sin respuesta del servidor (${conn.responseCode})")
            }
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val tag = json.getString("tag_name")
            val remote = tag.substringAfterLast('.').toIntOrNull()
                ?: return@withContext UpdateState.Failed("Versión no válida")

            val assets = json.getJSONArray("assets")
            var apkUrl: String? = null
            for (i in 0 until assets.length()) {
                val asset = assets.getJSONObject(i)
                if (asset.getString("name").endsWith(".apk")) {
                    apkUrl = asset.getString("browser_download_url")
                    break
                }
            }
            if (apkUrl != null && remote > currentVersionCode()) {
                UpdateState.Available(tag.removePrefix("v"), apkUrl)
            } else {
                UpdateState.UpToDate
            }
        } catch (e: Exception) {
            UpdateState.Failed("No se pudo comprobar. Revisa tu conexión.")
        }
    }

    @Suppress("DEPRECATION")
    private fun currentVersionCode(): Int {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) info.longVersionCode.toInt() else info.versionCode
    }
}
