package com.optimizador

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.view.View
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import android.os.Build
import com.optimizador.assistant.FocusPrompt
import com.optimizador.assistant.NavRequest
import com.optimizador.assistant.NovaMsg
import com.optimizador.assistant.ServerClient
import com.optimizador.engine.ReviveReport
import com.optimizador.engine.ReviveState
import com.optimizador.engine.UsageHelper
import com.optimizador.privacy.AppPrivacy
import com.optimizador.privacy.PrivacyScanner
import com.optimizador.ui.LigeroTheme
import com.optimizador.ui.LigeroThemes
import com.optimizador.ui.ThemeCode
import kotlinx.coroutines.withContext
import java.time.LocalTime
import com.optimizador.core.DeviceSnapshot
import com.optimizador.core.HealthScore
import com.optimizador.core.PerformanceScanner
import com.optimizador.core.Recommendation
import com.optimizador.core.RecommendationEngine
import com.optimizador.data.EngineLog
import com.optimizador.data.Prefs
import com.optimizador.engine.CrashRecorder
import com.optimizador.engine.BoostState
import com.optimizador.engine.PerformanceEngine
import com.optimizador.engine.SpeedBooster
import com.optimizador.launch.AppEntry
import com.optimizador.launch.AppIndex
import com.optimizador.launch.AppLauncher
import com.optimizador.launch.IconCache
import com.optimizador.update.UpdateChecker
import com.optimizador.update.UpdateInstaller
import com.optimizador.update.UpdateState
import com.optimizador.weather.WeatherInfo
import com.optimizador.weather.WeatherRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun AppEntry.key(): String = component.flattenToString()

/** Casillas del inicio (4 columnas x 4 filas) y del dock (4). EMPTY marca una casilla libre. */
const val HOME_COLS = 4
const val HOME_ROWS = 4
const val HOME_SLOTS = HOME_COLS * HOME_ROWS
const val DOCK_SLOTS = 4
const val EMPTY = "-"

private fun padSlots(list: List<String>, n: Int): List<String> = (list + List(n) { EMPTY }).take(n)

class LigeroViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)
    val log = EngineLog(prefs)
    val index = AppIndex(app, viewModelScope).also { it.start() }
    val icons = IconCache(app)
    val launcher = AppLauncher(app)
    val engine = PerformanceEngine(app, log) { icons.trim() }
    private val updater = UpdateChecker(app)
    private val installer = UpdateInstaller(app)

    var themeIndex by mutableIntStateOf(prefs.themeIndex)
    var ultraLight by mutableStateOf(prefs.ultraLight)
    var autoUpdate by mutableStateOf(prefs.autoUpdateCheck)
    var noAnim by mutableStateOf(prefs.noAnim)

    val home = mutableStateListOf<String>()
    val dock = mutableStateListOf<String>()
    val hidden = mutableStateListOf<String>()
    var launchCounts by mutableStateOf<Map<String, Int>>(emptyMap())
    var menuFor by mutableStateOf<AppEntry?>(null)
    var lastCrash by mutableStateOf<String?>(null)
    var update by mutableStateOf<UpdateState>(UpdateState.Idle)

    private val weatherRepo = WeatherRepository(app, prefs)
    private val booster = SpeedBooster(app, icons)
    var city by mutableStateOf(prefs.city)
    var weather by mutableStateOf<WeatherInfo?>(weatherRepo.saved())
    var boostState by mutableStateOf<BoostState>(BoostState.Idle)

    val server = ServerClient(prefs)
    private val usage = UsageHelper(app)
    private val privacyScanner = PrivacyScanner(app)

    val novaMessages = mutableStateListOf<NovaMsg>()
    var novaMood by mutableStateOf("idle")
    var novaOpen by mutableStateOf(false)
    var navRequest by mutableStateOf<NavRequest?>(null)

    var reviveState by mutableStateOf<ReviveState>(ReviveState.Idle)
    var tips by mutableStateOf<List<String>>(emptyList())
    var privacyApps by mutableStateOf<List<AppPrivacy>?>(null)
    var usageToday by mutableStateOf<Map<String, Int>>(emptyMap())
    val limits = mutableStateMapOf<String, Int>()
    var focusPrompt by mutableStateOf<FocusPrompt?>(null)
    var routineCounts by mutableStateOf<Map<String, Int>>(emptyMap())
    var textMode by mutableStateOf(prefs.textMode)
    var communityOptIn by mutableStateOf(prefs.communityOptIn)
    var serverUrl by mutableStateOf(prefs.serverUrl)
    val customThemes = mutableStateListOf<LigeroTheme>()

    var snapshot by mutableStateOf<DeviceSnapshot?>(null)
    var score by mutableIntStateOf(0)
    var recommendations by mutableStateOf<List<Recommendation>>(emptyList())

    init {
        home.addAll(padSlots(prefs.getList("home"), HOME_SLOTS))
        dock.addAll(padSlots(prefs.getList("dock"), DOCK_SLOTS))
        hidden.addAll(prefs.getList("hidden"))
        launchCounts = prefs.launchCounts()
        routineCounts = prefs.routineCounts()
        limits.putAll(prefs.limits())
        prefs.getList("customThemes").mapNotNull { ThemeCode.decode(it) }.forEach { customThemes.add(it) }

        CrashRecorder.consume(app)?.let {
            lastCrash = it
            log.add("Se recuperó de un cierre inesperado: todo quedó como estaba")
        }

        viewModelScope.launch { index.apps.collect { ensureDefaults(it) } }
        viewModelScope.launch {
            while (true) {
                engine.sample()
                delay(5000)
            }
        }
        viewModelScope.launch {
            while (true) {
                refreshWeather()
                delay(60_000)
            }
        }
        if (prefs.autoUpdateCheck) {
            viewModelScope.launch {
                delay(4000)
                checkUpdate()
            }
        }
    }

    // ---------- Inicio, dock y apps ocultas ----------

    private fun ensureDefaults(apps: List<AppEntry>) {
        if (apps.isEmpty()) return
        val needDock = !prefs.hasKey("dock")
        val needHome = !prefs.hasKey("home")
        if (needDock) {
            defaultDock(apps).take(DOCK_SLOTS).forEachIndexed { i, k -> dock[i] = k }
        }
        if (needHome) {
            val skip = dock.toSet()
            apps.map { it.key() }.filter { it !in skip }.take(8).forEachIndexed { i, k -> home[i] = k }
        }
        if (needDock || needHome) saveSlots()
    }

    private fun defaultDock(apps: List<AppEntry>): List<String> {
        val pm = getApplication<Application>().packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
        )
        val result = mutableListOf<String>()
        for (intent in intents) {
            val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
                ?: continue
            apps.firstOrNull { it.packageName == pkg }?.let { result.add(it.key()) }
        }
        return result.distinct()
    }

    private fun saveSlots() {
        prefs.putList("home", home.toList())
        prefs.putList("dock", dock.toList())
    }

    /** Pone la app en la primera casilla libre del inicio, o la quita si ya estaba. */
    fun toggleHome(key: String) {
        val i = home.indexOf(key)
        if (i >= 0) {
            home[i] = EMPTY
        } else {
            val free = home.indexOf(EMPTY)
            if (free >= 0) home[free] = key else log.add("No hay espacio libre en el inicio")
        }
        saveSlots()
    }

    fun toggleDock(key: String) {
        val i = dock.indexOf(key)
        if (i >= 0) {
            dock[i] = EMPTY
        } else {
            val free = dock.indexOf(EMPTY)
            if (free >= 0) dock[free] = key else log.add("No hay espacio libre en el dock")
        }
        saveSlots()
    }

    fun hide(key: String) {
        if (key !in hidden) hidden.add(key)
        for (i in home.indices) if (home[i] == key) home[i] = EMPTY
        for (i in dock.indices) if (dock[i] == key) dock[i] = EMPTY
        prefs.putList("hidden", hidden.toList())
        saveSlots()
    }

    private fun slotGet(id: String): String {
        val n = id.substring(1).toIntOrNull() ?: return EMPTY
        return if (id[0] == 'h') home.getOrElse(n) { EMPTY } else dock.getOrElse(n) { EMPTY }
    }

    private fun slotSet(id: String, value: String) {
        val n = id.substring(1).toIntOrNull() ?: return
        if (id[0] == 'h' && n in home.indices) home[n] = value
        if (id[0] == 'd' && n in dock.indices) dock[n] = value
    }

    /** Suelta una app arrastrada: la mueve a una casilla libre, la intercambia con otra, o la quita ("trash"). */
    fun dropOn(from: String, to: String) {
        if (from == to || from.isEmpty()) return
        if (to == "trash") {
            slotSet(from, EMPTY)
        } else {
            val a = slotGet(from)
            val b = slotGet(to)
            slotSet(to, a)
            slotSet(from, b)
        }
        saveSlots()
    }

    fun unhide(key: String) {
        hidden.remove(key)
        prefs.putList("hidden", hidden.toList())
    }

    fun suggested(apps: List<AppEntry>, n: Int = 4): List<AppEntry> =
        apps.filter { it.key() !in hidden && (launchCounts[it.key()] ?: 0) > 0 }
            .sortedByDescending { launchCounts[it.key()] ?: 0 }
            .take(n)

    fun launch(entry: AppEntry, view: View, x: Int, y: Int, w: Int, h: Int) {
        val limit = limits[entry.packageName]
        if (limit != null) {
            val used = usage.todayMinutes()[entry.packageName] ?: 0
            if (used >= limit) {
                focusPrompt = FocusPrompt(entry, used, limit)
                return
            }
        }
        recordLaunch(entry.key())
        launcher.open(entry, view, x, y, w, h, animate = !noAnim)
    }

    /** Lo usa Nova para abrir una app (respeta los límites de bienestar). */
    fun launchPlain(entry: AppEntry) {
        val limit = limits[entry.packageName]
        if (limit != null) {
            val used = usage.todayMinutes()[entry.packageName] ?: 0
            if (used >= limit) {
                focusPrompt = FocusPrompt(entry, used, limit)
                return
            }
        }
        recordLaunch(entry.key())
        launcher.openPlain(entry)
    }

    fun openAnyway(entry: AppEntry) {
        recordLaunch(entry.key())
        launcher.openPlain(entry)
        focusPrompt = null
    }

    private fun recordLaunch(k: String) {
        prefs.incLaunch(k)
        launchCounts = launchCounts + (k to ((launchCounts[k] ?: 0) + 1))
        val b = bucket()
        prefs.incRoutine(b, k)
        val rk = "$b:$k"
        routineCounts = routineCounts + (rk to ((routineCounts[rk] ?: 0) + 1))
    }

    // ---------- Rutina: un inicio que aprende en el propio celular ----------

    /** 0 madrugada, 1 mañana, 2 tarde, 3 noche. */
    fun bucket(): Int = when (LocalTime.now().hour) {
        in 0..5 -> 0
        in 6..11 -> 1
        in 12..17 -> 2
        else -> 3
    }

    fun bucketName(): String = listOf("de madrugada", "esta mañana", "esta tarde", "esta noche")[bucket()]

    /** Las apps que sueles abrir a esta hora del día (solo si ya hay datos). */
    fun suggestedNow(apps: List<AppEntry>, n: Int = 4): List<AppEntry> {
        val b = bucket()
        return apps.filter { it.key() !in hidden }
            .map { it to (routineCounts["$b:${it.key()}"] ?: 0) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .map { it.first }
            .take(n)
    }

    // ---------- Temas propios ----------

    fun allThemes(): List<LigeroTheme> = LigeroThemes + customThemes

    fun addCustomTheme(t: LigeroTheme) {
        if (customThemes.size >= 12) customThemes.removeAt(0)
        customThemes.add(t)
        prefs.putList("customThemes", customThemes.map { ThemeCode.encode(it) })
        chooseTheme(LigeroThemes.size + customThemes.size - 1)
    }

    // ---------- Revive tu celular ----------

    private fun dockPackages(): Set<String> = dock
        .mapNotNull { k -> index.apps.value.firstOrNull { it.key() == k }?.packageName }
        .toSet()

    fun startRevive() {
        if (reviveState is ReviveState.Running) return
        viewModelScope.launch {
            val scanner = PerformanceScanner(getApplication())
            reviveState = ReviveState.Running("Midiendo tu celular…")
            val before = withContext(Dispatchers.Default) { scanner.scan() }
            val scoreBefore = HealthScore.compute(before)

            val actions = mutableListOf<String>()
            val ids = mutableListOf<String>()
            reviveState = ReviveState.Running("Cerrando lo que sobra en segundo plano…")
            val r = booster.run(dockPackages())
            actions.add("Cerró procesos en segundo plano (memoria liberada: ${r.ramFreedMb} MB)")
            ids.add("boost")
            if (r.cacheFreedMb > 0) {
                actions.add("Limpió ${r.cacheFreedMb} MB de caché de Ligero")
                ids.add("cache")
            }

            reviveState = ReviveState.Running("Midiendo otra vez…")
            val after = withContext(Dispatchers.Default) { scanner.scan() }
            val scoreAfter = HealthScore.compute(after)
            val manual = RecommendationEngine().build(after).map { it.title + ". " + it.detail }

            snapshot = after
            score = scoreAfter
            recommendations = RecommendationEngine().build(after)
            reviveState = ReviveState.Done(
                ReviveReport(scoreBefore, scoreAfter, before.ramFreePct, after.ramFreePct, r.storageFreeGb, actions, manual)
            )
            log.add("Revive tu celular: salud de $scoreBefore a $scoreAfter")
            if (communityOptIn && server.configured) {
                server.report(Build.MODEL, Build.VERSION.SDK_INT, after.totalRamMb, scoreBefore, scoreAfter, ids)
            }
        }
    }

    fun loadTips() {
        if (!server.configured || !communityOptIn) return
        viewModelScope.launch { tips = server.tips(Build.MODEL) }
    }

    // ---------- Privacidad y bienestar ----------

    fun scanPrivacy() {
        viewModelScope.launch { privacyApps = withContext(Dispatchers.Default) { privacyScanner.scan() } }
    }

    fun refreshUsage() {
        viewModelScope.launch { usageToday = withContext(Dispatchers.Default) { usage.todayMinutes() } }
    }

    fun setLimit(pkg: String, minutes: Int) {
        if (minutes <= 0) limits.remove(pkg) else limits[pkg] = minutes
        prefs.setLimit(pkg, minutes)
    }

    fun setTextMode(on: Boolean) {
        textMode = on
        prefs.textMode = on
    }

    fun setCommunity(on: Boolean) {
        communityOptIn = on
        prefs.communityOptIn = on
    }

    fun setServerUrl(u: String) {
        prefs.serverUrl = u
        serverUrl = prefs.serverUrl
    }

    // ---------- Ajustes ----------

    fun chooseTheme(i: Int) {
        themeIndex = i
        prefs.themeIndex = i
    }

    fun setUltraLight(on: Boolean) {
        ultraLight = on
        prefs.ultraLight = on
        log.add(if (on) "Modo ultraligero activado" else "Modo ultraligero desactivado")
    }

    fun setNoAnim(on: Boolean) {
        noAnim = on
        prefs.noAnim = on
        log.add(if (on) "Animaciones desactivadas" else "Animaciones activadas")
    }

    fun setAutoUpdate(on: Boolean) {
        autoUpdate = on
        prefs.autoUpdateCheck = on
    }

    // ---------- Clima ----------

    fun setCity(c: String) {
        city = c.trim()
        prefs.city = city
        refreshWeather(force = true)
    }

    /** Actualiza el clima si pasaron 30 minutos (o si se pide a la fuerza). */
    fun refreshWeather(force: Boolean = false) {
        if (city.isBlank()) return
        val age = System.currentTimeMillis() - (weather?.updatedAt ?: 0L)
        if (!force && (age < 30 * 60_000L || engine.lowMemory)) return
        viewModelScope.launch {
            val result = weatherRepo.fetch(city)
            if (result != null) {
                weather = result
                weatherRepo.save(result)
            } else {
                log.add("No se pudo actualizar el clima")
            }
        }
    }

    // ---------- Cohete ----------

    fun boost() {
        if (boostState is BoostState.Running) return
        viewModelScope.launch {
            boostState = BoostState.Running
            val protectedPackages = dock
                .mapNotNull { k -> index.apps.value.firstOrNull { it.key() == k }?.packageName }
                .toSet()
            val r = booster.run(protectedPackages)
            boostState = BoostState.Done(r)
            log.add("Cohete: liberó ${r.ramFreedMb} MB de memoria y ${r.cacheFreedMb} MB de caché")
        }
    }

    fun dismissBoost() {
        boostState = BoostState.Idle
    }

    // ---------- Memoria ----------

    fun onTrim(level: Int) {
        if (level in 5..15) {
            icons.trim()
            log.add("El sistema pidió memoria: liberó la caché de íconos")
        }
    }

    // ---------- Diagnóstico ----------

    fun scan() {
        viewModelScope.launch(Dispatchers.Default) {
            val s = PerformanceScanner(getApplication()).scan()
            val recs = RecommendationEngine().build(s)
            val sc = HealthScore.compute(s)
            snapshot = s
            recommendations = recs
            score = sc
        }
    }

    // ---------- Actualizaciones ----------

    fun checkUpdate() {
        if (engine.lowMemory) return
        viewModelScope.launch {
            update = UpdateState.Checking
            val result = updater.check()
            update = result
            if (result is UpdateState.Available) log.add("Hay una versión nueva: ${result.version}")
        }
    }

    fun startUpdate() {
        val available = update as? UpdateState.Available ?: return
        update = UpdateState.Downloading
        installer.start(available.url) { started ->
            if (!started) update = available
        }
    }

    override fun onCleared() {
        index.stop()
    }
}
