package com.optimizador.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.AdaptiveUiController
import com.optimizador.adaptive.UiTier

/** Motor de rendimiento: muestra lo que mide y las reglas que aplica solo. */
@Composable
fun EngineScreen(vm: LigeroViewModel, controller: AdaptiveUiController, tier: UiTier, theme: LigeroTheme) {
    val sample by controller.lastSample.collectAsState()
    val eng = vm.engine
    val fps = sample?.fps ?: 0
    val jank = ((sample?.jankRatio ?: 0f) * 100).toInt()

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        LText("Motor de rendimiento", 27, FontWeight.Bold)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Medidor("Memoria libre", "${eng.memFreePct}%", eng.memFreePct / 100f, tier, theme, Modifier.weight(1f))
            Medidor("Fluidez", if (sample == null) "–" else "$fps fps", (fps / 60f).coerceIn(0f, 1f), tier, theme, Modifier.weight(1f))
            Medidor("Tirones", "$jank%", (jank / 100f).coerceIn(0f, 1f), tier, theme, Modifier.weight(1f))
        }

        LText("Reglas que se aplican solas", 14, alpha = .8f)
        Regla("Poca memoria", "Libera la caché de íconos y pausa tareas secundarias",
            if (eng.lowMemory) "Activa" else "En espera", tier, theme)
        Regla("Sobrecarga", "Quita efectos visuales prescindibles",
            if (tier != controller.startTier) "Activa" else "En espera", tier, theme)
        Regla("App lenta al abrir", "La interfaz nunca espera: todo se carga fuera del hilo principal",
            "Siempre activa", tier, theme)
        Regla("Error inesperado", "Anota el problema y recupera el estado guardado",
            if (vm.lastCrash != null) "Recuperado" else "Sin cierres", tier, theme)
        Regla("Todo fluido", "Mantiene la experiencia visual completa",
            if (tier == controller.startTier && !eng.lowMemory) "Activa" else "En espera", tier, theme)

        LText("Registro", 14, alpha = .8f)
        LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (vm.log.events.isEmpty()) LText("Todavía no hay eventos.", 13, alpha = .8f)
                vm.log.events.take(8).forEach { LText(it, 12, alpha = .9f) }
            }
        }
        Box(Modifier.height(90.dp))
    }
}

@Composable
private fun Medidor(label: String, value: String, fraction: Float, tier: UiTier, theme: LigeroTheme, modifier: Modifier) {
    LiquidPanel(tier, theme, modifier, RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            LText(label, 12, alpha = .8f)
            LText(value, 19, FontWeight.Bold)
            Box(Modifier.fillMaxWidth().height(6.dp).background(LocalInk.current.copy(.18f), RoundedCornerShape(3.dp))) {
                Box(
                    Modifier.fillMaxWidth(fraction.coerceIn(0.02f, 1f)).height(6.dp)
                        .background(theme.highlight, RoundedCornerShape(3.dp))
                )
            }
        }
    }
}

@Composable
private fun Regla(title: String, detail: String, status: String, tier: UiTier, theme: LigeroTheme) {
    LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                LText(title, 14, FontWeight.SemiBold)
                LText(detail, 12, alpha = .8f)
            }
            LText(status, 12, FontWeight.Bold, color = theme.highlight, modifier = Modifier.padding(start = 10.dp))
        }
    }
}
