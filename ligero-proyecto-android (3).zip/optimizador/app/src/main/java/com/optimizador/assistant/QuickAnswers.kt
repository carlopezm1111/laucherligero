package com.optimizador.assistant

import java.text.Normalizer
import java.util.Locale

/** Lo que el buscador y Nova pueden resolver solos, sin internet. */
sealed interface Quick {
    data class Answer(val title: String) : Quick
    data class Timer(val seconds: Int, val label: String) : Quick
    data class Alarm(val hour: Int, val minute: Int) : Quick
}

/**
 * Calculadora, porcentajes, conversión de unidades, temporizadores y alarmas escritos en lenguaje normal:
 * "15% de 80", "2+3*4", "5 millas a km", "temporizador de 10 minutos", "alarma a las 7:30".
 */
object QuickAnswers {

    fun answer(raw: String): Quick? {
        val t = normalize(raw)
        if (t.isBlank()) return null
        timer(t)?.let { return it }
        alarm(t)?.let { return it }
        percent(t)?.let { return it }
        convert(t)?.let { return it }
        return calc(t)
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase().trim(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace("°", "")
            .replace(',', '.')

    private fun num(v: Double): String =
        if (v == Math.rint(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else "%.4f".format(Locale.US, v).trimEnd('0').trimEnd('.')

    private fun duration(sec: Int): String = when {
        sec % 3600 == 0 -> "${sec / 3600} h"
        sec % 60 == 0 -> "${sec / 60} min"
        else -> "$sec s"
    }

    // ---------- temporizador y alarma ----------

    private val timerRx = Regex("""(?:temporizador|timer|avisame en|avisame)\s*(?:de|en)?\s*(\d+(?:\.\d+)?)\s*(segundos|segundo|seg|minutos|minuto|min|horas|hora|h)\b""")
    private val alarmRx = Regex("""(?:alarma|despiertame|despierta)\D*?(\d{1,2})(?::(\d{2}))?\s*(am|pm|de la manana|de la tarde|de la noche)?""")

    private fun timer(t: String): Quick? {
        val m = timerRx.find(t) ?: return null
        val n = m.groupValues[1].toDouble()
        val unit = m.groupValues[2]
        val secs = when {
            unit.startsWith("h") -> n * 3600
            unit.startsWith("min") -> n * 60
            else -> n
        }.toInt()
        if (secs <= 0) return null
        return Quick.Timer(secs, "Temporizador de ${duration(secs)}")
    }

    private fun alarm(t: String): Quick? {
        val m = alarmRx.find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val suffix = m.groupValues[3]
        val pm = suffix == "pm" || suffix == "de la tarde" || suffix == "de la noche"
        val am = suffix == "am" || suffix == "de la manana"
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (h > 23 || min > 59) return null
        return Quick.Alarm(h, min)
    }

    // ---------- porcentajes ----------

    private val percentRx = Regex("""(\d+(?:\.\d+)?)\s*%\s*de\s*(\d+(?:\.\d+)?)""")

    private fun percent(t: String): Quick? {
        val m = percentRx.find(t) ?: return null
        val p = m.groupValues[1].toDouble()
        val x = m.groupValues[2].toDouble()
        return Quick.Answer("${num(p)}% de ${num(x)} = ${num(p * x / 100.0)}")
    }

    // ---------- unidades ----------

    private class U(val cat: String, val f: Double)

    private val UNITS: Map<String, U> = buildMap {
        fun add(names: List<String>, cat: String, f: Double) { names.forEach { put(it, U(cat, f)) } }
        add(listOf("m", "metro", "metros"), "L", 1.0)
        add(listOf("km", "kilometro", "kilometros"), "L", 1000.0)
        add(listOf("cm", "centimetro", "centimetros"), "L", 0.01)
        add(listOf("mm", "milimetro", "milimetros"), "L", 0.001)
        add(listOf("milla", "millas", "mi"), "L", 1609.344)
        add(listOf("pie", "pies", "ft"), "L", 0.3048)
        add(listOf("pulgada", "pulgadas", "in"), "L", 0.0254)
        add(listOf("kg", "kilo", "kilos", "kilogramo", "kilogramos"), "M", 1.0)
        add(listOf("g", "gramo", "gramos"), "M", 0.001)
        add(listOf("lb", "libra", "libras"), "M", 0.45359237)
        add(listOf("oz", "onza", "onzas"), "M", 0.028349523)
        add(listOf("l", "litro", "litros"), "V", 1.0)
        add(listOf("ml", "mililitro", "mililitros"), "V", 0.001)
        add(listOf("galon", "galones", "gal"), "V", 3.785411784)
    }

    private val convRx = Regex("""(-?\d+(?:\.\d+)?)\s*(?:grados\s*)?([a-z]+)\s*(?:a|en|to|->)\s*(?:grados\s*)?([a-z]+)""")

    private fun tempKind(u: String): Char? = when (u) {
        "c", "celsius", "centigrados" -> 'c'
        "f", "fahrenheit" -> 'f'
        "k", "kelvin" -> 'k'
        else -> null
    }

    private fun convert(t: String): Quick? {
        val m = convRx.find(t) ?: return null
        val v = m.groupValues[1].toDouble()
        val a = m.groupValues[2]
        val b = m.groupValues[3]
        val ta = tempKind(a)
        val tb = tempKind(b)
        if (ta != null && tb != null) {
            val c = when (ta) { 'c' -> v; 'f' -> (v - 32) * 5 / 9; else -> v - 273.15 }
            val out = when (tb) { 'c' -> c; 'f' -> c * 9 / 5 + 32; else -> c + 273.15 }
            return Quick.Answer("${num(v)}° ${a.uppercase()} = ${num(out)}° ${b.uppercase()}")
        }
        val ua = UNITS[a] ?: return null
        val ub = UNITS[b] ?: return null
        if (ua.cat != ub.cat) return null
        return Quick.Answer("${num(v)} $a = ${num(v * ua.f / ub.f)} $b")
    }

    // ---------- calculadora ----------

    private fun calc(t: String): Quick? {
        val s = t.replace("x", "*").replace("×", "*").replace("÷", "/").replace(" ", "")
        if (!s.matches(Regex("""[0-9+\-*/^().]+""")) || s.none { it in "+-*/^" }) return null
        return try {
            val v = Parser(s).parse()
            if (v.isNaN() || v.isInfinite()) null else Quick.Answer("${t.trim()} = ${num(v)}")
        } catch (e: Exception) {
            null
        }
    }

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double {
            val v = expr()
            if (i != s.length) throw IllegalArgumentException()
            return v
        }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = pow()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]
                val r = pow()
                v = if (op == '*') v * r else v / r
            }
            return v
        }
        fun pow(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') {
                i++
                return Math.pow(b, pow())
            }
            return b
        }
        fun unary(): Double {
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '+') { i++; return unary() }
            return atom()
        }
        fun atom(): Double {
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException()
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException()
            return s.substring(st, i).toDouble()
        }
    }
}
