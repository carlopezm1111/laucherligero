package com.optimizador.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.AdaptiveUiController

@Composable
fun LigeroApp(vm: LigeroViewModel, controller: AdaptiveUiController) {
    val tier by controller.tier.collectAsState()
    val allThemes = vm.allThemes()
    val theme = allThemes[vm.themeIndex.coerceIn(allThemes.indices)]
    var drawer by remember { mutableStateOf(false) }
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val c = WindowCompat.getInsetsController(window, view)
            c.isAppearanceLightStatusBars = theme.light
            c.isAppearanceLightNavigationBars = theme.light
        }
    }
    val ms = if (vm.noAnim) 0 else (260 * tier.animScale).toInt()

    // El botón atrás cierra primero el menú y luego el cajón.
    BackHandler(enabled = drawer || vm.menuFor != null) {
        if (vm.menuFor != null) vm.menuFor = null else drawer = false
    }

    MaterialTheme {
        Wallpaper(theme, tier) {
            Box(Modifier.fillMaxSize()) {
                HomeScreen(vm, controller, tier, theme, drawer) { drawer = true }

                AnimatedVisibility(
                    visible = drawer,
                    enter = slideInVertically(tween(ms)) { it },
                    exit = slideOutVertically(tween(ms)) { it }
                ) {
                    DrawerScreen(vm, tier, theme) { drawer = false }
                }

                NovaLayer(vm, tier, theme)
                AppMenu(vm, tier, theme)
                FocusOverlay(vm, tier, theme)
            }
        }
    }
}
