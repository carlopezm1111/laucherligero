package com.optimizador.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.key
import com.optimizador.launch.AppEntry
import com.optimizador.launch.launcherTap

/**
 * Un ícono de app: toque sin espera para abrir, mantener pulsado para el menú.
 * Si recibe slotId y drag, también se puede arrastrar a otra casilla del inicio o del dock.
 */
@Composable
fun AppIcon(
    entry: AppEntry,
    vm: LigeroViewModel,
    showLabel: Boolean = true,
    modifier: Modifier = Modifier,
    slotId: String? = null,
    drag: DragController? = null
) {
    val view = LocalView.current
    val bounds = remember { IntArray(4) }
    val icon by produceState<ImageBitmap?>(null, entry.component) {
        value = vm.icons.load(entry)?.asImageBitmap()
    }
    val lifted = drag?.entry?.key() == entry.key() && drag?.from == slotId

    Column(
        modifier
            .alpha(if (lifted) 0.25f else 1f)
            .onGloballyPositioned {
                val p = it.positionInRoot()
                bounds[0] = p.x.toInt()
                bounds[1] = p.y.toInt()
                bounds[2] = it.size.width
                bounds[3] = it.size.height
            }
            .launcherTap(
                onTap = { vm.launch(entry, view, bounds[0], bounds[1], bounds[2], bounds[3]) },
                onLongPress = { vm.menuFor = entry },
                dragEnabled = drag != null && slotId != null,
                origin = { Offset(bounds[0].toFloat(), bounds[1].toFloat()) },
                onDragStart = { p ->
                    drag?.let {
                        it.entry = entry
                        it.from = slotId ?: ""
                        it.pos = p
                        it.over = ""
                    }
                },
                onDrag = { p ->
                    drag?.let {
                        it.pos = p
                        it.over = it.hit(p) ?: ""
                    }
                },
                onDragEnd = {
                    drag?.let {
                        val to = it.hit(it.pos)
                        val from = it.from
                        it.entry = null
                        it.over = ""
                        if (to != null) vm.dropOn(from, to)
                    }
                }
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (!vm.textMode) {
            Box(Modifier.size(56.dp)) {
                icon?.let { Image(it, contentDescription = entry.label, modifier = Modifier.fillMaxSize()) }
            }
        }
        if (showLabel || vm.textMode) {
            LText(
                entry.label, if (vm.textMode) 15 else 11, maxLines = 1, align = TextAlign.Center,
                modifier = if (vm.textMode) Modifier.padding(vertical = 12.dp) else Modifier
            )
        }
    }
}
