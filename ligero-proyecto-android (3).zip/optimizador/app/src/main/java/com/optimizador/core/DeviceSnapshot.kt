package com.optimizador.core

/** Foto del estado actual del celular. Nada aquí identifica a la persona. */
data class DeviceSnapshot(
    val model: String,            // p. ej. "SM-A125F"
    val androidSdk: Int,
    val totalRamMb: Long,
    val freeRamMb: Long,
    val totalStorageMb: Long,
    val freeStorageMb: Long,
    val animationScale: Float,    // 1.0 = normal
    val installedAppCount: Int,
    val heavyBackgroundApps: List<String>
) {
    val storageUsedPct: Int
        get() = (100 - (freeStorageMb * 100 / totalStorageMb)).toInt()
    val ramFreePct: Int
        get() = (freeRamMb * 100 / totalRamMb).toInt()
}
