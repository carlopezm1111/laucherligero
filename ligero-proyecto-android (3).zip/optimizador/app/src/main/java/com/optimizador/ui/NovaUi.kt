package com.optimizador.ui

import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier
import com.optimizador.assistant.novaConfirm
import com.optimizador.assistant.novaSay
import com.optimizador.assistant.novaSend
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private val SUGERENCIAS = listOf(
    "¿Por qué va lento mi celular?", "Acelera mi celular", "Abre Fotos", "Alarma a las 7",
    "15% de 80", "5 millas a km", "Revisa mi privacidad", "¿Cómo está el clima?"
)

/**
 * Nova, la asistente: una esfera de cristal que flota sobre Ligero. Se arrastra, se pega a los bordes
 * y, al tocarla, abre el chat. Solo vive dentro de Ligero.
 */
@Composable
fun NovaLayer(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }
        val orbPx = with(density) { 84.dp.toPx() }
        val margin = with(density) { 8.dp.toPx() }
        var pos by remember(wPx, hPx) { mutableStateOf(Offset(wPx - orbPx - margin, hPx * 0.55f)) }
        val animate = tier == UiTier.COMPLETO && !vm.noAnim

        if (vm.novaOpen) NovaChat(vm, theme)

        Box(
            Modifier
                .offset { IntOffset(pos.x.roundToInt(), pos.y.roundToInt()) }
                .size(84.dp)
                .pointerInput(Unit) {
                    detectTapGestures(onTap = {
                        vm.novaOpen = !vm.novaOpen
                        if (vm.novaOpen && vm.novaMessages.isEmpty()) {
                            vm.novaSay("¡Hola! Soy Nova. Pídeme algo y lo hago por ti. Escribe «ayuda» para ver qué sé hacer.")
                        }
                    })
                }
                .pointerInput(wPx, hPx) {
                    detectDragGestures(
                        onDragEnd = {
                            val left = pos.x + orbPx / 2 < wPx / 2
                            pos = Offset(if (left) margin else wPx - orbPx - margin, pos.y)
                        },
                        onDrag = { change, drag ->
                            change.consume()
                            pos = Offset(
                                (pos.x + drag.x).coerceIn(0f, wPx - orbPx),
                                (pos.y + drag.y).coerceIn(0f, hPx - orbPx)
                            )
                        }
                    )
                }
        ) {
            NovaOrb(vm.novaMood, animate)
        }
    }
}

@Composable
private fun floatAnim(animate: Boolean, from: Float, to: Float, ms: Int, reverse: Boolean, easing: androidx.compose.animation.core.Easing = LinearEasing): State<Float> {
    if (!animate) return remember { mutableStateOf((from + to) / 2f) }
    val t = rememberInfiniteTransition(label = "nova")
    return t.animateFloat(
        from, to,
        infiniteRepeatable(tween(ms, easing = easing), if (reverse) RepeatMode.Reverse else RepeatMode.Restart),
        label = "anim"
    )
}

/** El dibujo de Nova: esfera de cristal, visor con ojos que cambian de expresión, anillo y propulsor. */
@Composable
fun NovaOrb(mood: String, animate: Boolean) {
    val bob = floatAnim(animate, -3f, 3f, 1300, true, FastOutSlowInEasing)
    val orbit = floatAnim(animate, 0f, (2 * PI).toFloat(), 3400, false)
    val blink = floatAnim(animate, 0f, 1f, 4200, false)
    val scan = floatAnim(animate, -1f, 1f, 900, true)
    val ring = floatAnim(animate, 0f, 1f, 1400, false)

    Canvas(Modifier.fillMaxSize()) {
        val s = size.width / 120f
        val b = bob.value
        val cx = 60f * s
        val cy = (56f + b) * s
        val cyan = Color(0xFF5CF2FF)
        val violet = Color(0xFFA47BFF)
        val eye = Color(0xFF7CF7FF)
        val rim = Brush.linearGradient(
            listOf(Color(0xFFD4FAFF), cyan.copy(alpha = .25f), violet),
            start = Offset(14f * s, 40f * s), end = Offset(106f * s, 80f * s)
        )

        // propulsor
        drawOval(
            Brush.radialGradient(listOf(cyan.copy(alpha = .85f), Color.Transparent), center = Offset(60f * s, 110f * s), radius = 24f * s),
            topLeft = Offset(38f * s, 104f * s), size = Size(44f * s, 11f * s)
        )
        // ondas cuando escucha o piensa
        if ((mood == "listen" || mood == "think") && animate) {
            val r = ring.value
            drawCircle(cyan.copy(alpha = (1f - r) * .8f), radius = (36f + 16f * r) * s, center = Offset(cx, cy), style = Stroke(1.6f * s))
        }
        // anillo (mitad de atrás)
        drawArc(rim, 180f, 180f, false, Offset(14f * s, cy - 12f * s + 2f * s), Size(92f * s, 24f * s), style = Stroke(1.6f * s))
        // esfera
        drawCircle(
            Brush.radialGradient(
                0f to Color(0xFF6F8BFF), .42f to Color(0xFF1D2C80), 1f to Color(0xFF060A24),
                center = Offset(46f * s, cy - 12f * s), radius = 62f * s
            ),
            radius = 34f * s, center = Offset(cx, cy)
        )
        drawCircle(
            Brush.radialGradient(.72f to cyan.copy(alpha = 0f), 1f to cyan.copy(alpha = .75f), center = Offset(cx, cy), radius = 34f * s),
            radius = 34f * s, center = Offset(cx, cy)
        )
        drawCircle(rim, radius = 34f * s, center = Offset(cx, cy), style = Stroke(1.6f * s))
        // visor
        drawRoundRect(Color(0xF004081C), Offset(33f * s, cy - 11f * s), Size(54f * s, 24f * s), CornerRadius(12f * s))
        drawRoundRect(cyan.copy(alpha = .35f), Offset(33f * s, cy - 11f * s), Size(54f * s, 24f * s), CornerRadius(12f * s), style = Stroke(1f * s))

        // ojos según el ánimo
        val ey = cy + 1f * s
        fun glowOval(x: Float, rx: Float, ry: Float, col: Color) {
            drawOval(col.copy(alpha = .28f), Offset(x - rx * 1.7f, ey - ry * 1.5f), Size(rx * 3.4f, ry * 3f))
            drawOval(col, Offset(x - rx, ey - ry), Size(rx * 2f, ry * 2f))
        }
        when (mood) {
            "happy" -> for (x in listOf(48f * s, 72f * s)) {
                drawArc(eye, 200f, 140f, false, Offset(x - 6f * s, ey - 5f * s), Size(12f * s, 12f * s), style = Stroke(3.2f * s, cap = StrokeCap.Round))
            }
            "think" -> for (x in listOf(48f * s, 71.5f * s)) {
                val dx = scan.value * 5f * s
                drawRoundRect(eye.copy(alpha = .3f), Offset(x - 8f * s + dx, ey - 4f * s), Size(16f * s, 8f * s), CornerRadius(4f * s))
                drawRoundRect(eye, Offset(x - 6.5f * s + dx, ey - 2.2f * s), Size(13f * s, 4.4f * s), CornerRadius(2.2f * s))
            }
            "listen" -> { glowOval(48f * s, 6.4f * s, 8.2f * s, Color(0xFF9BFAFF)); glowOval(72f * s, 6.4f * s, 8.2f * s, Color(0xFF9BFAFF)) }
            else -> {
                val closed = blink.value in 0.95f..1f
                val ry = if (closed) 0.7f * s else 6.6f * s
                glowOval(48f * s, 5.2f * s, ry, eye); glowOval(72f * s, 5.2f * s, ry, eye)
            }
        }

        // reflejos y nodos laterales
        rotate(-28f, Offset(45f * s, cy - 21f * s)) {
            drawOval(Color.White.copy(alpha = .38f), Offset(30f * s, cy - 27.5f * s), Size(30f * s, 13f * s))
        }
        drawOval(violet.copy(alpha = .4f), Offset(67f * s, cy + 22f * s), Size(18f * s, 6f * s))
        drawCircle(cyan.copy(alpha = .3f), 5.5f * s, Offset(22f * s, cy + 2f * s)); drawCircle(cyan, 3.2f * s, Offset(22f * s, cy + 2f * s))
        drawCircle(violet.copy(alpha = .3f), 5.5f * s, Offset(98f * s, cy + 2f * s)); drawCircle(violet, 3.2f * s, Offset(98f * s, cy + 2f * s))
        // anillo (mitad de adelante) y la luz que lo recorre
        drawArc(rim, 0f, 180f, false, Offset(14f * s, cy - 12f * s + 2f * s), Size(92f * s, 24f * s), style = Stroke(1.8f * s))
        val a = orbit.value
        val bead = Offset(cx + 46f * s * cos(a), cy + 2f * s + 12f * s * sin(a))
        drawCircle(Color(0xFFD4FAFF).copy(alpha = .35f), 6f * s, bead)
        drawCircle(Color(0xFFD4FAFF), 3.1f * s, bead)
    }
}

@Composable
private fun NovaChat(vm: LigeroViewModel, theme: LigeroTheme) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { vm.novaSend(it) }
    }
    val ctx = LocalContext.current
    LaunchedEffect(vm.novaMessages.size) {
        if (vm.novaMessages.isNotEmpty()) listState.animateScrollToItem(vm.novaMessages.lastIndex)
    }
    val userText = if (theme.light) Color.White else Color(0xFF06241C)

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        Column(
            Modifier.navigationBarsPadding().imePadding().padding(12.dp).fillMaxWidth()
                .background(theme.panel.copy(alpha = 0.97f), RoundedCornerShape(26.dp))
                .border(1.dp, Color.White.copy(alpha = .25f), RoundedCornerShape(26.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                LText("Nova", 17, FontWeight.Bold)
                Box(Modifier.size(40.dp).clickable { vm.novaOpen = false }, contentAlignment = Alignment.Center) { LText("×", 24) }
            }
            LazyColumn(state = listState, modifier = Modifier.heightIn(max = 250.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(vm.novaMessages) { i, m ->
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.fromUser) Alignment.End else Alignment.Start) {
                        Column(
                            Modifier
                                .background(if (m.fromUser) theme.highlight else LocalInk.current.copy(alpha = .12f), RoundedCornerShape(16.dp))
                                .padding(horizontal = 13.dp, vertical = 9.dp)
                        ) {
                            LText(m.text, 14, color = if (m.fromUser) userText else LocalInk.current)
                            if (m.confirm != null) {
                                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Chip(m.confirm.yesLabel, true, theme) { vm.novaConfirm(i, true) }
                                    Chip("No", false, theme) { vm.novaConfirm(i, false) }
                                }
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SUGERENCIAS.forEach { s -> Chip(s, false, theme) { vm.novaSend(s) } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).heightIn(min = 46.dp)
                        .background(LocalInk.current.copy(alpha = .10f), RoundedCornerShape(50))
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    BasicTextField(
                        value = input, onValueChange = { input = it }, singleLine = true,
                        textStyle = TextStyle(color = LocalInk.current, fontSize = 15.sp),
                        cursorBrush = SolidColor(LocalInk.current),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { vm.novaSend(input); input = "" }),
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { inner ->
                            if (input.isEmpty()) LText("Pídeme algo…", 15, alpha = .6f)
                            inner()
                        }
                    )
                }
                Chip("Voz", false, theme) {
                    try {
                        speech.launch(
                            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es")
                                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Dime qué hago")
                        )
                    } catch (e: Exception) {
                        vm.novaSay("Este celular no tiene reconocimiento de voz disponible.")
                    }
                }
                Chip("Enviar", true, theme) { vm.novaSend(input); input = "" }
            }
        }
    }
}

@Composable
private fun Chip(text: String, strong: Boolean, theme: LigeroTheme, onClick: () -> Unit) {
    val fg = if (strong) (if (theme.light) Color.White else Color(0xFF06241C)) else LocalInk.current
    Box(
        Modifier
            .heightIn(min = 40.dp)
            .background(if (strong) theme.highlight else LocalInk.current.copy(alpha = .10f), CircleShape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        LText(text, 13, FontWeight.SemiBold, color = fg)
    }
}
