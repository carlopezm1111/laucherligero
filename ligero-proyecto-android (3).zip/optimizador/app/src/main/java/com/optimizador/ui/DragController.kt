package com.optimizador.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import com.optimizador.launch.AppEntry

/**
 * Estado del arrastre de apps en el inicio.
 * bounds guarda dónde está cada casilla en la pantalla ("h0".."h15" = inicio, "d0".."d3" = dock,
 * "trash" = zona de quitar). hit() dice qué casilla hay bajo el dedo.
 */
class DragController {
    var entry by mutableStateOf<AppEntry?>(null)
    var pos by mutableStateOf(Offset.Zero)
    var over by mutableStateOf("")
    var from: String = ""
    val bounds = mutableMapOf<String, Rect>()

    fun hit(p: Offset): String? {
        bounds["trash"]?.let { if (it.contains(p)) return "trash" }
        return bounds.entries.firstOrNull { it.key != "trash" && it.value.contains(p) }?.key
    }
}
