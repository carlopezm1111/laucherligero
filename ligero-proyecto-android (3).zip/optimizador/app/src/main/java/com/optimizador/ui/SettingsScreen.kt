package com.optimizador.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.AdaptiveUiController
import com.optimizador.adaptive.UiTier
import com.optimizador.key
import com.optimizador.update.UpdateState
import com.optimizador.weather.label
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp

private val DESCRIPCIONES = mapOf(
    UiTier.COMPLETO to "Vidrio y animaciones completas. Para celulares potentes.",
    UiTier.EQUILIBRADO to "Menos efectos. Para celulares de gama media.",
    UiTier.LIGERO to "Paneles sólidos, sin transparencias. Para celulares viejos."
)

@Composable
fun SettingsScreen(vm: LigeroViewModel, controller: AdaptiveUiController, tier: UiTier, theme: LigeroTheme) {
    val ctx = LocalContext.current
    val apps by vm.index.apps.collectAsState()
    val byKey = remember(apps) { apps.associateBy { it.key() } }
    val sample by controller.lastSample.collectAsState()
    var auto by remember { mutableStateOf(controller.auto) }
    val versionName = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        LText("Ajustes", 27, FontWeight.Bold)

        LiquidPanel(tier, theme, Modifier.fillMaxWidth()) {
            Row(Modifier.padding(20.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    LText("Fluidez en vivo", 13, alpha = .8f)
                    LText("${sample?.fps ?: "–"} fps", 30, FontWeight.Bold, color = theme.highlight)
                }
                Column(horizontalAlignment = Alignment.End) {
                    LText("Tirones", 13, alpha = .8f)
                    LText("${((sample?.jankRatio ?: 0f) * 100).toInt()}%", 22, FontWeight.SemiBold)
                }
            }
        }

        UiTier.entries.forEach { t ->
            val selected = t == tier
            LiquidPanel(
                tier, theme,
                Modifier.fillMaxWidth()
                    .clickable {
                        vm.setUltraLight(false)
                        controller.setManual(t)
                        auto = false
                    }
                    .border(
                        if (selected) 2.dp else 0.dp,
                        if (selected) theme.highlight else Color.Transparent,
                        RoundedCornerShape(24.dp)
                    )
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    LText(t.name.lowercase().replaceFirstChar { it.uppercase() } + if (selected) " · activo" else "", 17, FontWeight.Bold)
                    LText(DESCRIPCIONES.getValue(t), 13, alpha = .8f)
                }
            }
        }

        Interruptor("Ajuste automático", "Cambia de nivel según la fluidez", auto, tier, theme) {
            auto = it
            controller.auto = it
        }
        Interruptor("Modo ultraligero", "Paneles sólidos y sin efectos, para el máximo rendimiento", vm.ultraLight, tier, theme) {
            vm.setUltraLight(it)
            controller.setUltraLight(it)
            auto = !it
        }

        Interruptor("Sin animaciones", "Ligero abre apps y cambia de pantalla al instante, sin efectos de movimiento", vm.noAnim, tier, theme) {
            vm.setNoAnim(it)
        }
        val sistemaAnim = remember {
            Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        }
        LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LText(
                    "Animaciones del sistema: " + if (sistemaAnim == 0f) "desactivadas" else "${sistemaAnim}x",
                    15, FontWeight.SemiBold
                )
                LText(
                    "Android no deja que una app cambie las animaciones de todo el celular. " +
                        "Para quitarlas, activa las Opciones de desarrollador y pon en “Animación desactivada” " +
                        "la escala de animación de ventana, de transición y de duración.",
                    12, alpha = .8f
                )
            }
        }
        GlassButton("Abrir opciones de desarrollador", tier, theme) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                // Si aún no están activadas, abrimos "Acerca del teléfono" para tocar 7 veces el número de compilación.
                ctx.startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        LText("Color de la interfaz", 15, alpha = .8f)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            vm.allThemes().forEachIndexed { i, th ->
                val sel = i == vm.themeIndex
                Box(
                    Modifier.size(44.dp)
                        .background(Brush.linearGradient(listOf(th.blobs[0], th.blobs[1])), CircleShape)
                        .border(3.dp, if (sel) LocalInk.current else Color.Transparent, CircleShape)
                        .clickable { vm.chooseTheme(i) }
                )
            }
        }

        LText("Mis temas", 15, alpha = .8f)
        val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                val bmp = try {
                    ctx.contentResolver.openInputStream(uri)?.use { s ->
                        BitmapFactory.decodeStream(s, null, BitmapFactory.Options().apply { inSampleSize = 4 })
                    }
                } catch (e: Exception) {
                    null
                }
                if (bmp != null) vm.addCustomTheme(ThemeCode.fromPhoto(bmp, "Mi foto ${vm.customThemes.size + 1}"))
            }
        }
        GlassButton("Crear un tema con los colores de una foto", tier, theme) { pick.launch("image/*") }
        GlassButton("Compartir el tema actual", tier, theme) {
            val all = vm.allThemes()
            val current = all[vm.themeIndex.coerceIn(all.indices)]
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "Mi tema de Ligero: " + ThemeCode.encode(current))
            ctx.startActivity(Intent.createChooser(send, "Compartir tema").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        var importInput by remember { mutableStateOf("") }
        var importMsg by remember { mutableStateOf("") }
        LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                BasicTextField(
                    value = importInput, onValueChange = { importInput = it }, singleLine = true,
                    textStyle = TextStyle(color = LocalInk.current, fontSize = 15.sp),
                    cursorBrush = SolidColor(LocalInk.current),
                    decorationBox = { inner ->
                        if (importInput.isEmpty()) LText("Pega aquí un tema que te compartieron", 15, alpha = .6f)
                        inner()
                    }
                )
                if (importMsg.isNotEmpty()) LText(importMsg, 12, alpha = .85f)
            }
        }
        GlassButton("Importar tema", tier, theme) {
            val i = importInput.indexOf("LT1|")
            val code = if (i >= 0) importInput.substring(i).lines().first().trim() else importInput.trim()
            val t = ThemeCode.decode(code)
            if (t != null) {
                vm.addCustomTheme(t)
                importMsg = "Tema «${t.name}» agregado."
                importInput = ""
            } else {
                importMsg = "No reconocí ese código."
            }
        }

        LText("Nova y comunidad", 15, alpha = .8f)
        Interruptor(
            "Compartir resultados anónimos",
            "Al terminar «Revive tu celular» envía solo el modelo del celular y los puntajes (nada personal) para ayudar a otros celulares iguales. Apagado por defecto.",
            vm.communityOptIn, tier, theme
        ) { vm.setCommunity(it) }
        var serverInput by remember { mutableStateOf(vm.serverUrl) }
        LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                BasicTextField(
                    value = serverInput, onValueChange = { serverInput = it }, singleLine = true,
                    textStyle = TextStyle(color = LocalInk.current, fontSize = 15.sp),
                    cursorBrush = SolidColor(LocalInk.current),
                    decorationBox = { inner ->
                        if (serverInput.isEmpty()) LText("Servidor de Nova (opcional, avanzado)", 15, alpha = .6f)
                        inner()
                    }
                )
                LText(
                    "Sin servidor, Nova usa solo sus comandos propios (gratis e ilimitados). Con servidor, también responde preguntas libres con una IA gratuita con límite diario.",
                    12, alpha = .75f
                )
            }
        }
        GlassButton("Guardar servidor", tier, theme) { vm.setServerUrl(serverInput) }

        if (vm.hidden.isNotEmpty()) {
            LText("Apps ocultas", 15, alpha = .8f)
            vm.hidden.toList().forEach { k ->
                val label = byKey[k]?.label ?: k.substringBefore('/')
                GlassButton("Mostrar “$label”", tier, theme) { vm.unhide(k) }
            }
        }

        LText("Clima", 15, alpha = .8f)
        var cityInput by remember { mutableStateOf(vm.city) }
        LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                BasicTextField(
                    value = cityInput, onValueChange = { cityInput = it }, singleLine = true,
                    textStyle = TextStyle(color = LocalInk.current, fontSize = 16.sp),
                    cursorBrush = SolidColor(LocalInk.current),
                    decorationBox = { inner ->
                        if (cityInput.isEmpty()) LText("Escribe tu ciudad", 16, alpha = .6f)
                        inner()
                    }
                )
                LText(
                    vm.weather?.let { "${it.city}: ${it.tempC}° · ${it.sky.label(false)}" } ?: "Sin datos todavía",
                    13, alpha = .8f
                )
                LText("Solo se envía el nombre de la ciudad a Open-Meteo. No se usa la ubicación del celular.", 12, alpha = .7f)
            }
        }
        GlassButton("Guardar ciudad y actualizar clima", tier, theme) { vm.setCity(cityInput) }

        LText("Actualizaciones", 15, alpha = .8f)
        val u = vm.update
        val estado = when (u) {
            UpdateState.Idle -> "Sin comprobar todavía"
            UpdateState.Checking -> "Buscando…"
            UpdateState.UpToDate -> "Tienes la última versión"
            is UpdateState.Available -> "Hay una versión nueva: ${u.version}"
            UpdateState.Downloading -> "Descargando…"
            is UpdateState.Failed -> u.reason
        }
        LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LText(estado, 15, FontWeight.SemiBold)
                LText(
                    "Solo consulta la página de versiones de GitHub. No envía ningún dato tuyo. " +
                        "Tus ajustes se conservan al actualizar.",
                    12, alpha = .8f
                )
            }
        }
        if (u is UpdateState.Available) {
            GlassButton("Descargar e instalar", tier, theme) { vm.startUpdate() }
        } else {
            GlassButton("Buscar actualizaciones", tier, theme) { vm.checkUpdate() }
        }
        Interruptor("Buscar al abrir", "Revisa si hay versión nueva cada vez que abres Ligero", vm.autoUpdate, tier, theme) {
            vm.setAutoUpdate(it)
        }

        GlassButton("Usar Ligero como pantalla de inicio", tier, theme) {
            ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        LText("Versión $versionName", 12, alpha = .6f)
        Spacer(Modifier.height(90.dp))
    }
}

@Composable
fun Interruptor(
    title: String, detail: String, checked: Boolean, tier: UiTier, theme: LigeroTheme, onChange: (Boolean) -> Unit
) {
    LiquidPanel(tier, theme, Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(horizontal = 18.dp, vertical = 12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                LText(title, 15, FontWeight.SemiBold)
                LText(detail, 13, alpha = .8f)
            }
            GlassSwitch(checked, onChange, theme)
        }
    }
}
