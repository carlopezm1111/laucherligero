package com.optimizador.assistant

import com.optimizador.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Respuesta de la IA en línea: un texto y, opcionalmente, una acción que Nova puede hacer. */
data class AiReply(val reply: String, val action: String, val arg: String, val arg2: String)

/**
 * Habla con el servidor propio de Ligero (carpeta "servidor" del proyecto), que reparte las preguntas
 * entre IA gratuitas y limita las consultas diarias por celular. Si no hay servidor configurado,
 * Nova solo usa sus comandos propios. Nunca se envía la ubicación ni la lista de apps instaladas
 * completa: solo lo que la persona escribe y los nombres de sus apps para poder abrirlas.
 */
class ServerClient(private val prefs: Prefs) {

    val configured: Boolean get() = prefs.serverUrl.isNotBlank()

    suspend fun chat(text: String, apps: List<String>): AiReply? = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject()
                .put("text", text)
                .put("apps", JSONArray(apps.take(120)))
                .put("device", prefs.deviceId)
                .toString()
            val conn = open("/chat", "POST", body)
            if (conn.responseCode == 429) {
                return@withContext AiReply(
                    "Hoy ya usaste tus consultas gratuitas. Mañana vuelvo a tener cupo. Mientras tanto puedo abrir apps, poner alarmas y más con comandos.",
                    "none", "", ""
                )
            }
            if (conn.responseCode != 200) return@withContext null
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            AiReply(j.optString("reply"), j.optString("action", "none"), j.optString("arg"), j.optString("arg2"))
        } catch (e: Exception) {
            null
        }
    }

    /** Resultado anónimo de "Revive tu celular", solo si la persona lo permitió en Ajustes. */
    suspend fun report(model: String, sdk: Int, ramMb: Long, before: Int, after: Int, actions: List<String>) {
        withContext(Dispatchers.IO) {
            try {
                val body = JSONObject()
                    .put("model", model).put("sdk", sdk).put("ramMb", ramMb)
                    .put("before", before).put("after", after)
                    .put("actions", JSONArray(actions))
                    .toString()
                open("/report", "POST", body).responseCode
            } catch (e: Exception) {
                // Si falla, no pasa nada: es opcional.
            }
        }
    }

    /** Qué les funcionó a otros celulares del mismo modelo. */
    suspend fun tips(model: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val conn = open("/tips?model=" + URLEncoder.encode(model, "UTF-8"), "GET", null)
            if (conn.responseCode != 200) return@withContext emptyList()
            val arr = JSONObject(conn.inputStream.bufferedReader().use { it.readText() }).optJSONArray("tips")
                ?: return@withContext emptyList()
            List(arr.length()) { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun open(path: String, method: String, body: String?): HttpURLConnection {
        val c = URL(prefs.serverUrl + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 10_000
        c.readTimeout = 25_000
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        return c
    }
}
