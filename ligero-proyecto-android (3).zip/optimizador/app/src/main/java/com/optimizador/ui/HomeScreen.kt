package com.optimizador.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.optimizador.DOCK_SLOTS
import com.optimizador.EMPTY
import com.optimizador.HOME_COLS
import com.optimizador.HOME_ROWS
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.AdaptiveUiController
import com.optimizador.adaptive.UiTier
import com.optimizador.key
import com.optimizador.launch.AppEntry
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Tres páginas en horizontal: [Ajustes] [Inicio] [Resumen].
 * Empieza en el Inicio; deslizar hacia la derecha abre Ajustes.
 * En el Inicio, mantén pulsada una app y arrástrala a cualquier casilla libre, al dock o a "Quitar".
 */
@Composable
fun HomeScreen(
    vm: LigeroViewModel,
    controller: AdaptiveUiController,
    tier: UiTier,
    theme: LigeroTheme,
    drawerOpen: Boolean,
    onOpenDrawer: () -> Unit
) {
    val apps by vm.index.apps.collectAsState()
    val byKey = remember(apps) { apps.associateBy { it.key() } }
    val pager = rememberPagerState(initialPage = 1, pageCount = { 3 })
    val scope = rememberCoroutineScope()
    val drag = remember { DragController() }
    var section by remember { mutableIntStateOf(-1) }
    var clockMode by remember { mutableStateOf(false) }
    val goTo: (Int) -> Unit = { page ->
        scope.launch { if (vm.noAnim) pager.scrollToPage(page) else pager.animateScrollToPage(page) }
    }
    val goSettings: () -> Unit = { goTo(0) }

    // Nova (o cualquier otra parte) puede pedir que se abra una sección.
    LaunchedEffect(vm.navRequest) {
        val r = vm.navRequest ?: return@LaunchedEffect
        vm.navRequest = null
        when {
            r.clock -> clockMode = true
            r.drawer -> onOpenDrawer()
            else -> {
                section = r.section
                goTo(0)
            }
        }
    }

    // Atrás: primero cierra una sección de ajustes, luego vuelve al inicio.
    BackHandler(enabled = !drawerOpen && section >= 0) { section = -1 }
    BackHandler(enabled = !drawerOpen && section < 0 && pager.currentPage != 1) { goTo(1) }
    BackHandler(enabled = clockMode) { clockMode = false }

    Box(Modifier.fillMaxSize()) {
        HorizontalPager(pager, modifier = Modifier.fillMaxSize()) { page ->
            when (page) {
                0 -> SettingsHub(vm, controller, tier, theme, section) { section = it }
                1 -> HomeFrame(vm, tier, theme, byKey, drag, 0, onOpenDrawer, goSettings, { clockMode = true }) {
                    HomePage(vm, tier, theme, byKey, drag, onOpenDrawer) { clockMode = true }
                }
                else -> HomeFrame(vm, tier, theme, byKey, drag, 1, onOpenDrawer, goSettings, { clockMode = true }) {
                    SummaryPage(vm, tier, theme, byKey.values.toList())
                }
            }
        }
        DragOverlay(vm, drag, tier, theme)
        BoostOverlay(vm, tier, theme)
        if (clockMode) ClockMode(vm, tier, theme) { clockMode = false }
    }
}

/** Marco común de Inicio y Resumen: reloj, contenido, puntos y dock. */
@Composable
private fun HomeFrame(
    vm: LigeroViewModel,
    tier: UiTier,
    theme: LigeroTheme,
    byKey: Map<String, AppEntry>,
    drag: DragController,
    dotIndex: Int,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenClock: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(20_000)
        }
    }
    val locale = Locale.forLanguageTag("es")

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .pointerInput(Unit) {
                val threshold = 60.dp.toPx()
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -threshold) onOpenDrawer() },
                    onDragCancel = {}
                ) { _, dy -> total += dy }
            }
    ) {
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.clickable { onOpenClock() }) {
                LText(now.format(DateTimeFormatter.ofPattern("HH:mm")), 64, FontWeight.Light)
                LText(now.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", locale)), 15, alpha = .85f)
            }
            LiquidPanel(tier, theme, Modifier.clickable { onOpenSettings() }, RoundedCornerShape(50)) {
                LText("Ajustes ›", 13, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp))
            }
        }
        Spacer(Modifier.height(14.dp))

        Column(Modifier.weight(1f).fillMaxWidth(), content = content)

        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
            repeat(2) { i ->
                val on = dotIndex == i
                Box(
                    Modifier.padding(horizontal = 3.dp)
                        .size(width = if (on) 18.dp else 6.dp, height = 6.dp)
                        .background(LocalInk.current.copy(alpha = if (on) 1f else .35f), CircleShape)
                )
            }
        }

        LiquidPanel(
            tier, theme,
            Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 14.dp),
            RoundedCornerShape(34.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp)) {
                for (i in 0 until DOCK_SLOTS) {
                    val key = vm.dock.getOrElse(i) { EMPTY }
                    Slot("d$i", if (key == EMPTY) null else byKey[key], vm, drag, false, Modifier.weight(1f).height(64.dp))
                }
            }
        }
    }
}

/** Una casilla del inicio o del dock. Registra su posición para saber dónde se suelta una app. */
@Composable
private fun Slot(
    id: String,
    entry: AppEntry?,
    vm: LigeroViewModel,
    drag: DragController,
    showLabel: Boolean,
    modifier: Modifier
) {
    val dragging = drag.entry != null
    val hover = drag.over == id
    Box(
        modifier.onGloballyPositioned { drag.bounds[id] = it.boundsInRoot() },
        contentAlignment = Alignment.TopCenter
    ) {
        if (dragging && (entry == null || hover)) {
            Box(
                Modifier.size(58.dp).border(
                    if (hover) 2.dp else 1.dp,
                    LocalInk.current.copy(alpha = if (hover) .9f else .25f),
                    RoundedCornerShape(16.dp)
                )
            )
        }
        if (entry != null) AppIcon(entry, vm, showLabel, slotId = id, drag = drag)
    }
}

@Composable
private fun HomePage(
    vm: LigeroViewModel,
    tier: UiTier,
    theme: LigeroTheme,
    byKey: Map<String, AppEntry>,
    drag: DragController,
    onOpenDrawer: () -> Unit,
    onOpenClock: () -> Unit
) {
    val now by rememberNow()
    val hour = now.hour + now.minute / 60f
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        WeatherWidget(vm, tier, theme, hour, onOpenClock)

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LiquidPanel(
                tier, theme, Modifier.weight(1f).clickable { onOpenDrawer() }, RoundedCornerShape(50)
            ) {
                LText(
                    "Buscar apps y ajustes", 15, alpha = .8f,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)
                )
            }
            RocketWidget(vm, tier, theme)
        }

        for (r in 0 until HOME_ROWS) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0 until HOME_COLS) {
                    val i = r * HOME_COLS + c
                    val key = vm.home.getOrElse(i) { EMPTY }
                    Slot("h$i", if (key == EMPTY) null else byKey[key], vm, drag, true, Modifier.weight(1f).height(78.dp))
                }
            }
        }
    }
}

/** Mientras arrastras: el ícono sigue al dedo y arriba aparece la zona "Quitar". */
@Composable
private fun DragOverlay(vm: LigeroViewModel, drag: DragController, tier: UiTier, theme: LigeroTheme) {
    val entry = drag.entry ?: return
    val icon by produceState<ImageBitmap?>(null, entry.component) {
        value = vm.icons.load(entry)?.asImageBitmap()
    }
    val half = with(LocalDensity.current) { 34.dp.toPx() }
    val hoverTrash = drag.over == "trash"

    DisposableEffect(Unit) { onDispose { drag.bounds.remove("trash") } }

    Box(Modifier.fillMaxSize()) {
        LiquidPanel(
            tier, theme,
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 10.dp)
                .onGloballyPositioned { drag.bounds["trash"] = it.boundsInRoot() },
            RoundedCornerShape(50)
        ) {
            LText(
                if (hoverTrash) "Suelta para quitar" else "Quitar de inicio", 14,
                FontWeight.SemiBold,
                color = if (hoverTrash) theme.highlight else LocalInk.current,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp)
            )
        }
        icon?.let {
            Image(
                it, contentDescription = null,
                modifier = Modifier
                    .offset { IntOffset((drag.pos.x - half).roundToInt(), (drag.pos.y - half).roundToInt()) }
                    .size(68.dp)
                    .graphicsLayer { scaleX = 1.12f; scaleY = 1.12f }
                    .alpha(0.95f)
            )
        }
    }
}

@Composable
private fun SummaryPage(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme, apps: List<AppEntry>) {
    val suggested = vm.suggested(apps)
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        LText("Resumen", 22, FontWeight.Bold)
        LiquidPanel(tier, theme, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LText("Memoria libre", 13, alpha = .8f)
                LText("${vm.engine.memFreePct}%", 28, FontWeight.Bold, color = theme.highlight)
                LText(
                    if (vm.engine.lowMemory) "Poca memoria: el motor liberó recursos" else "Todo en orden",
                    13, alpha = .8f
                )
            }
        }
        val now = vm.suggestedNow(apps)
        LText("Para ${vm.bucketName()}", 15, alpha = .8f)
        if (now.isEmpty()) {
            LText("Con el tiempo aprendo qué apps usas a esta hora y te las pongo aquí. Todo se guarda solo en tu celular.", 13, alpha = .7f)
        } else {
            Row(Modifier.fillMaxWidth()) {
                now.forEach { AppIcon(it, vm, modifier = Modifier.weight(1f)) }
                repeat(4 - now.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        LText("Las que más usas", 15, alpha = .8f)
        if (suggested.isEmpty()) {
            LText("Aún no hay datos. Cuando abras apps desde Ligero, aparecerán aquí.", 13, alpha = .7f)
        } else {
            Row(Modifier.fillMaxWidth()) {
                suggested.forEach { AppIcon(it, vm, modifier = Modifier.weight(1f)) }
                repeat(4 - suggested.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
