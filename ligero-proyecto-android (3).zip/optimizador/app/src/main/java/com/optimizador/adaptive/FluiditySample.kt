package com.optimizador.adaptive

/** Resultado de medir un periodo de ~1 segundo. */
data class FluiditySample(
    val fps: Int,
    /** Fracción de fotogramas que tardaron más de 1.5x lo que permite la pantalla. 0.0 a 1.0 */
    val jankRatio: Float
)
