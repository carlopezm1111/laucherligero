package com.optimizador.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier
import com.optimizador.engine.ReviveState

/**
 * Revive tu celular: mide, aplica lo que Android permite, y muestra el antes y el después con números medidos.
 * Si el problema no era la memoria, el puntaje puede no cambiar: la pantalla lo dice con honestidad.
 */
@Composable
fun ReviveScreen(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.loadTips() }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        LText("Revive tu celular", 27, FontWeight.Bold)
        LText("Mide tu celular, hace lo que Android permite y te muestra el antes y el después.", 14, alpha = .8f)

        when (val st = vm.reviveState) {
            ReviveState.Idle -> GlassButton("Revisar y acelerar", tier, theme) { vm.startRevive() }
            is ReviveState.Running -> LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                LText(st.step, 16, FontWeight.SemiBold, modifier = Modifier.padding(20.dp))
            }
            is ReviveState.Done -> {
                val r = st.report
                LiquidPanel(tier, theme, Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(22.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            LText("Antes", 13, alpha = .8f)
                            LText("${r.scoreBefore}", 46, FontWeight.Bold)
                            LText("memoria libre ${r.ramFreeBefore}%", 12, alpha = .8f)
                        }
                        LText("→", 28)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            LText("Después", 13, alpha = .8f)
                            LText("${r.scoreAfter}", 46, FontWeight.Bold, color = theme.highlight)
                            LText("memoria libre ${r.ramFreeAfter}%", 12, alpha = .8f)
                        }
                    }
                }
                if (r.scoreAfter <= r.scoreBefore) {
                    LText(
                        "El puntaje casi no cambió: tu celular no estaba limitado por la memoria. Mira abajo los pasos que faltan.",
                        13, alpha = .85f
                    )
                }
                LText("Lo que hizo Ligero", 15, alpha = .8f)
                r.actions.forEach { a ->
                    LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(16.dp)) {
                        LText(a, 14, modifier = Modifier.padding(14.dp))
                    }
                }
                if (r.manualSteps.isNotEmpty()) {
                    LText("Lo que falta, y solo puedes hacer tú", 15, alpha = .8f)
                    r.manualSteps.forEach { a ->
                        LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(16.dp)) {
                            LText(a, 13, alpha = .9f, modifier = Modifier.padding(14.dp))
                        }
                    }
                }
                GlassButton("Compartir resultado", tier, theme) {
                    val text = "Con Ligero mi celular pasó de ${r.scoreBefore} a ${r.scoreAfter} de salud " +
                        "(memoria libre ${r.ramFreeBefore}% → ${r.ramFreeAfter}%)."
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                    ctx.startActivity(Intent.createChooser(send, "Compartir").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                GlassButton("Limpiar más espacio", tier, theme) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        // Si el celular no tiene esa pantalla, no pasa nada.
                    }
                }
                GlassButton("Volver a medir", tier, theme) { vm.startRevive() }
            }
        }

        if (vm.tips.isNotEmpty()) {
            LText("A otros celulares como el tuyo les funcionó", 15, alpha = .8f)
            vm.tips.forEach { tip ->
                LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(16.dp)) {
                    LText(tip, 14, modifier = Modifier.padding(14.dp))
                }
            }
        }
        Box(Modifier.height(90.dp))
    }
}
