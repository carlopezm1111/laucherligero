package com.optimizador.ui

import android.content.Intent
import android.provider.MediaStore
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.optimizador.LigeroViewModel
import com.optimizador.adaptive.UiTier
import com.optimizador.update.UpdateState
import com.optimizador.weather.Sky
import com.optimizador.weather.WeatherScene
import com.optimizador.weather.isNight
import com.optimizador.weather.label
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Modo reloj: pantalla completa con el reloj grande de cristal y el clima animado de fondo.
 * No reemplaza la pantalla de bloqueo del sistema (Android no lo permite): se abre tocando el reloj.
 * Se cierra tocando la pantalla, deslizando hacia arriba o con el botón atrás.
 */
@Composable
fun ClockMode(vm: LigeroViewModel, tier: UiTier, theme: LigeroTheme, onClose: () -> Unit) {
    val now by rememberNow()
    val hour = now.hour + now.minute / 60f
    val w = vm.weather
    val sky = w?.sky ?: Sky.SOL
    val animate = tier == UiTier.COMPLETO && !vm.noAnim
    val ctx = LocalContext.current
    val h12 = (now.hour % 12).let { if (it == 0) 12 else it }
    val time = "%d:%02d".format(h12, now.minute)
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale.forLanguageTag("es")))
        .replaceFirstChar { it.uppercase() }
    val size = 104.sp

    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                val threshold = 60.dp.toPx()
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -threshold) onClose() },
                    onDragCancel = {}
                ) { _, dy -> total += dy }
            }
            .clickable { onClose() }
    ) {
        WeatherScene(sky, hour, animate, Modifier.fillMaxSize())

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(48.dp))
            LText(date, 20, FontWeight.SemiBold, color = Color.White)
            Box {
                // Contorno brillante y relleno que se desvanece: el efecto de cristal del reloj.
                Text(
                    time,
                    style = TextStyle(
                        fontSize = size, fontWeight = FontWeight.Bold, letterSpacing = (-5).sp,
                        color = Color.White.copy(alpha = .6f), drawStyle = Stroke(width = 3f)
                    )
                )
                Text(
                    time,
                    style = TextStyle(
                        fontSize = size, fontWeight = FontWeight.Bold, letterSpacing = (-5).sp,
                        brush = Brush.verticalGradient(listOf(Color.White.copy(alpha = .85f), Color.White.copy(alpha = .14f)))
                    )
                )
            }
            Spacer(Modifier.height(10.dp))
            LiquidPanel(tier, theme, shape = RoundedCornerShape(50)) {
                Row(
                    Modifier.padding(horizontal = 22.dp, vertical = 11.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LText(if (w != null) "${w.tempC}°" else "--°", 22, FontWeight.SemiBold, color = Color.White)
                    LText(sky.label(isNight(hour)), 15, color = Color.White)
                }
            }
            (vm.update as? UpdateState.Available)?.let {
                Spacer(Modifier.height(16.dp))
                LiquidPanel(tier, theme, Modifier.fillMaxWidth(), RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                        LText("Ligero", 14, FontWeight.Bold, color = Color.White)
                        LText("Hay una versión nueva: ${it.version}", 13, color = Color.White, alpha = .9f)
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Spacer(Modifier.size(56.dp))
                LText("Toca o desliza hacia arriba para cerrar", 12, color = Color.White, alpha = .85f, align = TextAlign.Center)
                LiquidPanel(
                    tier, theme,
                    Modifier.size(56.dp).clickable {
                        try {
                            ctx.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e: Exception) {
                            // Sin cámara disponible: no se hace nada.
                        }
                    },
                    CircleShape
                ) {
                    LText("Cámara", 10, color = Color.White, align = TextAlign.Center, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    }
}
