package com.optimizador.engine

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Environment
import android.os.StatFs
import com.optimizador.launch.IconCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

data class BoostResult(
    val ramFreedMb: Long,
    val ramFreePct: Int,
    val cacheFreedMb: Long,
    val appsChecked: Int,
    val storageFreeGb: Float
)

sealed interface BoostState {
    data object Idle : BoostState
    data object Running : BoostState
    data class Done(val result: BoostResult) : BoostState
}

/**
 * El botón del cohete: con un toque hace dos cosas.
 * 1) Pide a Android que cierre los procesos en segundo plano de las apps (no toca las del sistema,
 *    ni las del dock, ni Ligero). Android decide cuáles puede cerrar, y algunas se vuelven a abrir solas.
 * 2) Borra la caché y los archivos temporales de Ligero.
 * Android NO deja que una app borre la caché de otras apps: para eso se abre el limpiador del sistema.
 * Los números del resultado son medidos antes y después, no inventados.
 */
class SpeedBooster(private val context: Context, private val icons: IconCache) {

    suspend fun run(protectedPackages: Set<String>): BoostResult = withContext(Dispatchers.Default) {
        val am = context.getSystemService(ActivityManager::class.java)
        fun memory(): ActivityManager.MemoryInfo = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }

        val before = memory().availMem

        var checked = 0
        for (app in context.packageManager.getInstalledApplications(0)) {
            val pkg = app.packageName
            if (pkg == context.packageName || pkg in protectedPackages) continue
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            am.killBackgroundProcesses(pkg)
            checked++
        }

        icons.trim()
        var freed = deleteContents(context.cacheDir)
        context.externalCacheDir?.let { freed += deleteContents(it) }
        val update = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "ligero-update.apk")
        if (update.exists()) {
            freed += update.length()
            update.delete()
        }

        delay(900) // se espera un momento para que Android actualice la lectura de memoria
        val info = memory()
        val mb = 1024L * 1024L
        BoostResult(
            ramFreedMb = max(0L, (info.availMem - before) / mb),
            ramFreePct = if (info.totalMem > 0) (info.availMem * 100 / info.totalMem).toInt() else 0,
            cacheFreedMb = freed / mb,
            appsChecked = checked,
            storageFreeGb = StatFs(Environment.getDataDirectory().path).availableBytes / 1_000_000_000f
        )
    }

    private fun deleteContents(dir: File): Long {
        var total = 0L
        dir.listFiles()?.forEach { f ->
            total += if (f.isDirectory) deleteContents(f) else f.length()
            f.delete()
        }
        return total
    }
}
