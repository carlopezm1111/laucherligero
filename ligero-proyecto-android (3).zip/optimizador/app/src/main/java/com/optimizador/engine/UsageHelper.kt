package com.optimizador.engine

import android.app.usage.UsageStatsManager
import android.content.Context
import java.util.Calendar

/** Tiempo de uso de hoy por app. Devuelve vacío si la persona no concedió "Acceso a datos de uso". */
class UsageHelper(private val context: Context) {
    fun todayMinutes(): Map<String, Int> {
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            usm.queryAndAggregateUsageStats(cal.timeInMillis, System.currentTimeMillis())
                .filterValues { it.totalTimeInForeground > 0 }
                .mapValues { (it.value.totalTimeInForeground / 60_000L).toInt() }
        } catch (e: Exception) {
            emptyMap()
        }
    }
}
