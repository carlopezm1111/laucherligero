package com.optimizador.assistant

import android.app.Application
import android.app.SearchManager
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import androidx.lifecycle.viewModelScope
import com.optimizador.LigeroViewModel
import com.optimizador.key
import com.optimizador.launch.AppEntry
import com.optimizador.weather.isNight
import com.optimizador.weather.label
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.Normalizer
import java.time.LocalTime

private fun norm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

private fun LigeroViewModel.startNew(intent: Intent): Boolean = try {
    getApplication<Application>().startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    true
} catch (e: Exception) {
    false
}

fun LigeroViewModel.novaSay(text: String, confirm: PendingAction? = null) {
    novaMood = "happy"
    novaMessages.add(NovaMsg(false, text, confirm))
    viewModelScope.launch {
        delay(1800)
        novaMood = "idle"
    }
}

/** La persona tocó "Sí" o "No" en un mensaje que pedía confirmación. */
fun LigeroViewModel.novaConfirm(index: Int, yes: Boolean) {
    val m = novaMessages.getOrNull(index) ?: return
    val c = m.confirm ?: return
    novaMessages[index] = m.copy(confirm = null)
    if (yes) c.run() else novaSay("Está bien, no hago nada.")
}

fun LigeroViewModel.novaSend(raw: String) {
    val text = raw.trim()
    if (text.isEmpty()) return
    novaMessages.add(NovaMsg(true, text))
    novaMood = "think"
    viewModelScope.launch {
        delay(450)
        if (!novaRoute(text)) novaAskServer(text)
    }
}

private fun LigeroViewModel.findApp(q: String): AppEntry? {
    val n = norm(q).replace(Regex("[^a-z0-9 ]"), "").trim()
    if (n.isEmpty()) return null
    val apps = index.apps.value.filter { it.key() !in hidden }
    return apps.firstOrNull { it.searchKey == n }
        ?: apps.firstOrNull { it.searchKey.startsWith(n) }
        ?: apps.firstOrNull { it.searchKey.contains(n) }
}

private fun LigeroViewModel.askTimer(seconds: Int, label: String) {
    novaSay("Voy a abrir el reloj con ${label.lowercase()}. ¿Lo hago?", PendingAction {
        val ok = startNew(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        )
        novaSay(if (ok) "Listo, revisa el reloj." else "No encontré una app de reloj en este celular.")
    })
}

private fun LigeroViewModel.askAlarm(hour: Int, minute: Int) {
    val hm = "%d:%02d".format(hour, minute)
    novaSay("Voy a abrir el reloj con una alarma a las $hm. ¿La creo?", PendingAction {
        val ok = startNew(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        )
        novaSay(if (ok) "Listo, confirma la alarma en el reloj." else "No encontré una app de reloj en este celular.")
    })
}

private fun LigeroViewModel.chooseThemeByName(name: String): Boolean {
    val n = norm(name).trim()
    val i = allThemes().indexOfFirst { norm(it.name).startsWith(n) }
    if (i < 0) return false
    chooseTheme(i)
    novaSay("¡Listo! Cambié al tema ${allThemes()[i].name}.")
    return true
}

/** Comandos propios: gratis, instantáneos, sin internet. Devuelve false si no entendió. */
private fun LigeroViewModel.novaRoute(raw: String): Boolean {
    val t = norm(raw).trim()

    when (val q = QuickAnswers.answer(raw)) {
        is Quick.Answer -> { novaSay(q.title); return true }
        is Quick.Timer -> { askTimer(q.seconds, q.label); return true }
        is Quick.Alarm -> { askAlarm(q.hour, q.minute); return true }
        null -> Unit
    }

    if (Regex("^(hola|buenas|hey|holi)\\b").containsMatchIn(t) && t.length < 20) {
        novaSay("¡Hola! Soy Nova. ¿Qué hago por ti?"); return true
    }
    if (Regex("ayuda|que puedes|que sabes|que haces").containsMatchIn(t)) {
        novaSay(
            "Puedo abrir apps, poner alarmas y temporizadores, calcular y convertir unidades, acelerar tu celular con el cohete, " +
                "revisar por qué va lento, hacer un chequeo de privacidad, mostrarte tu tiempo de pantalla, cambiar el color y contarte el clima."
        )
        return true
    }
    if (Regex("acelera|cohete|libera|limpia|limpiar|mas rapido").containsMatchIn(t)) {
        novaSay("¡Voy con el cohete! Cierro lo que sobra y limpio la caché."); boost(); return true
    }
    if (Regex("por que.*lento|va lento|esta lento|revive|diagnostic|optimiza").containsMatchIn(t)) {
        navRequest = NavRequest(section = 3)
        novaSay("Voy a revisar tu celular y te cuento qué mejoró. Abrí «Revive tu celular».")
        startRevive(); return true
    }
    if (Regex("privacidad|permisos|me espian|espiando").containsMatchIn(t)) {
        navRequest = NavRequest(section = 4); scanPrivacy()
        novaSay("Abrí el chequeo de privacidad: te muestro qué apps tienen cámara, micrófono o ubicación."); return true
    }
    if (Regex("tiempo de pantalla|bienestar|cuanto tiempo|limite").containsMatchIn(t)) {
        navRequest = NavRequest(section = 5); refreshUsage()
        novaSay("Abrí tu bienestar digital: ahí ves cuánto usaste cada app y puedes poner límites."); return true
    }
    if (Regex("clima|tiempo hace|llueve|lluvia|temperatura|hace calor|hace frio").containsMatchIn(t)) {
        val w = weather
        val now = LocalTime.now()
        val night = isNight(now.hour + now.minute / 60f)
        novaSay(
            if (w == null) "Aún no elegiste tu ciudad. Ve a Ajustes, sección Clima."
            else "En ${w.city} hay ${w.sky.label(night).lowercase()}, ${w.tempC}°. Máxima ${w.maxC}° y mínima ${w.minC}°."
        )
        return true
    }
    Regex("(?:tema|color)\\s+(?:de\\s+|a\\s+)?(\\w+)").find(t)?.let { m ->
        if (chooseThemeByName(m.groupValues[1])) return true
        novaSay("No conozco ese color. Mira los temas disponibles en Ajustes."); return true
    }
    if (Regex("modo reloj|reloj grande|pantalla de bloqueo").containsMatchIn(t)) {
        navRequest = NavRequest(clock = true); novaSay("Abriendo el modo reloj."); return true
    }
    if (Regex("cajon|todas las apps").containsMatchIn(t)) {
        navRequest = NavRequest(drawer = true); novaSay("Aquí tienes todas tus apps."); return true
    }
    if (Regex("ajustes|configur").containsMatchIn(t) && !t.contains("abre ")) {
        navRequest = NavRequest(section = 0); novaSay("Abrí tus ajustes."); return true
    }
    if (Regex("que hora|hora es").containsMatchIn(t)) {
        novaSay("Son las ${"%d:%02d".format(LocalTime.now().hour, LocalTime.now().minute)}."); return true
    }
    Regex("(?:abre|abrir|ejecuta|lanza)\\s+(?:la\\s+|el\\s+|mi\\s+)?(.+)").find(t)?.let { m ->
        val e = findApp(m.groupValues[1])
        if (e != null) { novaSay("Abriendo ${e.label}."); launchPlain(e) }
        else novaSay("No encontré una app con ese nombre.")
        return true
    }
    Regex("(?:busca|buscar|googlea|investiga)\\s+(.+)").find(t)?.let { m ->
        val q = m.groupValues[1]
        novaSay("Buscando «$q» en internet.")
        startNew(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
        return true
    }
    Regex("(?:mapa de|como llego a|llevame a|ruta a)\\s+(.+)").find(t)?.let { m ->
        val q = m.groupValues[1]
        novaSay("Abriendo el mapa para «$q».")
        startNew(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))
        return true
    }
    Regex("llama(?:r)?\\s*(?:al|a)?\\s*(\\+?[\\d\\s-]{3,})").find(t)?.let { m ->
        val digits = m.groupValues[1].filter { it.isDigit() || it == '+' }
        novaSay(
            "Voy a abrir el teléfono con el número $digits. Tú tocas llamar. ¿Lo hago?",
            PendingAction { startNew(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits"))) }
        )
        return true
    }
    return false
}

private suspend fun LigeroViewModel.novaAskServer(text: String) {
    if (!server.configured) {
        novaSay(
            "Eso necesita el cerebro de IA en línea, que todavía no está conectado. " +
                "Mientras tanto puedo abrir apps, poner alarmas, calcular, acelerar el celular y más. Pregúntame «ayuda»."
        )
        return
    }
    val names = index.apps.value.filter { it.key() !in hidden }.map { it.label }
    val r = server.chat(text, names)
    if (r == null) {
        novaSay("No pude conectarme al servidor de IA. Revisa tu internet e inténtalo otra vez.")
        return
    }
    novaApplyAi(r)
}

/** La IA solo puede pedir acciones de esta lista; las que tienen consecuencias piden confirmación. */
private fun LigeroViewModel.novaApplyAi(r: AiReply) {
    when (r.action) {
        "open_app" -> {
            val e = findApp(r.arg)
            if (e != null) { novaSay(r.reply.ifBlank { "Abriendo ${e.label}." }); launchPlain(e) }
            else novaSay(r.reply.ifBlank { "No encontré esa app." })
        }
        "web_search" -> {
            novaSay(r.reply.ifBlank { "Buscando «${r.arg}»." })
            startNew(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, r.arg))
        }
        "alarm" -> {
            val p = r.arg.split(":")
            val h = p.getOrNull(0)?.trim()?.toIntOrNull()
            val m = p.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
            if (h != null && h in 0..23 && m in 0..59) askAlarm(h, m) else novaSay(r.reply)
        }
        "timer" -> {
            val s = r.arg.trim().toIntOrNull()
            if (s != null && s > 0) askTimer(s, "Temporizador") else novaSay(r.reply)
        }
        "boost" -> { novaSay(r.reply.ifBlank { "¡Voy con el cohete!" }); boost() }
        "theme" -> if (!chooseThemeByName(r.arg)) novaSay(r.reply.ifBlank { "No conozco ese color." })
        else -> novaSay(r.reply.ifBlank { "No supe cómo ayudarte con eso." })
    }
}
