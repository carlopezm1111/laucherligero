package com.optimizador.core

/**
 * Idea 1 (comunidad) + Idea 2 (adaptación).
 * Hoy: reglas locales. Después: se le suman recomendaciones que llegan
 * del servidor para este mismo modelo de celular.
 */
class RecommendationEngine {

    fun localRules(s: DeviceSnapshot): List<Recommendation> = buildList {
        if (s.storageUsedPct >= 85) add(
            Recommendation(
                "storage", "Almacenamiento casi lleno (${s.storageUsedPct}%)",
                "Libera fotos duplicadas, descargas y cachés. Es lo que más frena un celular viejo.",
                Impact.ALTO
            )
        )
        if (s.ramFreePct < 20) add(
            Recommendation(
                "ram", "Poca memoria libre (${s.ramFreePct}%)",
                "Hay apps pesadas abiertas. Revisa las que más usas y desinstala las que no.",
                Impact.ALTO
            )
        )
        if (s.animationScale >= 1f) add(
            Recommendation(
                "anim", "Animaciones en velocidad normal",
                "Bajarlas a 0.5x en Opciones de desarrollador hace que todo se sienta más ágil.",
                Impact.MEDIO
            )
        )
        if (s.installedAppCount > 120) add(
            Recommendation(
                "apps", "${s.installedAppCount} apps instaladas",
                "Muchas apps dejan servicios en segundo plano. Quita las que no abres.",
                Impact.MEDIO
            )
        )
    }

    /** Mezcla local + comunidad, lo más importante primero. */
    fun build(s: DeviceSnapshot, community: List<Recommendation> = emptyList()) =
        (localRules(s) + community).sortedBy { it.impact.ordinal }
}
