package com.optimizador.launch

import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserHandle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.Normalizer

/**
 * Lista de apps en memoria, con el Intent de cada una ya armado.
 * Se carga fuera del hilo principal y se actualiza sola cuando se instala
 * o desinstala una app. Consultar al sistema es lento: aquí se hace una vez.
 */
class AppIndex(context: Context, private val scope: CoroutineScope) {

    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val me: UserHandle = Process.myUserHandle()

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps.asStateFlow()

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageAdded(p: String, u: UserHandle) = reload()
        override fun onPackageRemoved(p: String, u: UserHandle) = reload()
        override fun onPackageChanged(p: String, u: UserHandle) = reload()
        override fun onPackagesAvailable(p: Array<out String>, u: UserHandle, r: Boolean) = reload()
        override fun onPackagesUnavailable(p: Array<out String>, u: UserHandle, r: Boolean) = reload()
    }

    fun start() {
        launcherApps.registerCallback(callback)
        reload()
    }

    fun stop() = launcherApps.unregisterCallback(callback)

    private fun reload() {
        scope.launch(Dispatchers.Default) {
            _apps.value = launcherApps.getActivityList(null, me)
                .map { info ->
                    val label = info.label.toString()
                    val intent = Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setComponent(info.componentName)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    AppEntry(label, info.applicationInfo.packageName, info.componentName, intent, normalize(label))
                }
                .sortedBy { it.searchKey }
        }
    }

    /** Búsqueda 100% en memoria: cada letra filtra al instante, sin tocar el sistema. */
    fun search(query: String): List<AppEntry> {
        val q = normalize(query)
        if (q.isEmpty()) return _apps.value
        val list = _apps.value
        return list.filter { it.searchKey.startsWith(q) } +
            list.filter { !it.searchKey.startsWith(q) && it.searchKey.contains(q) }
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
}
