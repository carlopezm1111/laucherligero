# Ligero v0.3

Launcher ligero, rápido y privado.

## Inicio
- Páginas: Ajustes (a la izquierda), Inicio y Resumen. Cuadrícula de 4x4 y dock de 4 con arrastrar y soltar.
- Clima animado según la hora y el clima, modo reloj de cristal, cohete (acelerar y limpiar).
- Cajón por letras con buscador que también calcula, convierte unidades y crea temporizadores y alarmas.
- Sugeridas "para esta mañana/tarde/noche": aprende en el celular qué apps usas a cada hora.

## Nova (asistente flotante, solo dentro de Ligero)
- Comandos propios, gratis e ilimitados: abrir apps, alarmas, temporizadores, calcular, clima, colores, cohete, etc.
- Voz con el reconocimiento de voz de Android.
- IA para preguntas libres: opcional, necesita el servidor de la carpeta `servidor` (con límite diario).

## Pantalla de Ajustes (deslizar a la derecha)
- Revive tu celular (antes y después medidos), Ajustes, Diagnóstico, Motor de rendimiento, Privacidad y Bienestar.
- Temas: 7 incluidos, crear desde una foto, compartir e importar por código.

## Pendiente
Widgets de Android, carpetas, puntos de notificación, gestos extra, respaldo de configuración,
refracción real del vidrio, IA dentro del celular.
No se compiló aquí: se compila en GitHub Actions.
