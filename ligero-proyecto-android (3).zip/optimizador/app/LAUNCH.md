# Apertura de apps rápida

- AppIndex: lista de apps en memoria con el Intent de cada una ya armado; carga fuera
  del hilo principal y se actualiza sola al instalar o desinstalar apps.
- AppLauncher: en el toque solo lanza el Intent y arranca la animación. No calcula nada.
- Búsqueda: filtra en memoria, sin preguntar al sistema.

## Para medir (lo que convence a la gente)
- Macrobenchmark de Android: tiempo hasta que se muestra la pantalla de inicio y
  tiempo desde el toque hasta que la app abierta dibuja su primer fotograma.
- Comparar contra el launcher de fábrica en el mismo celular.

## Pendiente
- No se compiló ni se probó. Probar en celulares reales.
- En Compose, calcular x, y, w, h del ícono con onGloballyPositioned.
- Los iconos de AppEntry se cargan aparte, con la caché de íconos (siguiente paso).

## Toque sin espera (InstantTap.kt)
Modifier.instantTap { launcher.open(...) }: muestra el "presionado" al tocar, sin la
espera que Android mete dentro de contenedores que se desplazan, y abre al levantar el dedo.
Sin compilar: validar en celular real que no choque con el deslizamiento de páginas.
