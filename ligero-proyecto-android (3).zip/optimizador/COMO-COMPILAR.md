# Cómo compilar Ligero (paso a paso)

## Lo que necesitas
- Una computadora (Windows, Mac o Linux) con internet.
- Android Studio (gratis): https://developer.android.com/studio
- Un celular Android 8.0 o superior y un cable USB.

## 1. Abrir el proyecto
1. Descomprime este proyecto.
2. Abre Android Studio, elige **Open** y selecciona la carpeta `optimizador` (la que tiene `settings.gradle.kts`).
3. Espera a que termine "Gradle sync" (la primera vez descarga Gradle y las librerías; puede tardar varios minutos).
4. Si Android Studio ofrece actualizar versiones (Android Gradle Plugin, Kotlin), puedes aceptar, pero si algo falla, vuelve a las versiones originales.

## 2. Probarlo en tu celular
1. En el celular: Ajustes > Acerca del teléfono > toca 7 veces "Número de compilación". Luego activa **Depuración USB** en Opciones de desarrollador.
2. Conecta el celular al computador y acepta el aviso en la pantalla.
3. En Android Studio elige tu celular arriba y pulsa el botón verde de **Run**.
4. Al abrir, Android pregunta si quieres usar Ligero como pantalla de inicio (o hazlo desde la pestaña Interfaz).
   Para volver a tu launcher: Ajustes > Apps > Apps predeterminadas > Pantalla de inicio.

## 3. Sacar el APK para descargar
- Para pruebas: menú **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
  Queda en `app/build/outputs/apk/debug/app-debug.apk`. Se instala, pero está firmado con una llave de pruebas.
- Para publicar: **Build > Generate Signed App Bundle / APK > APK > Create new keystore**.
  GUARDA ese archivo de llave y su contraseña en un lugar seguro y con copia: sin ellos no podrás actualizar la app.

## 4. Si sale un error
Copia el texto rojo completo que muestra la pestaña **Build** y pásalo. El código no se ha compilado nunca,
así que es normal que aparezcan errores pequeños en la primera vez.
